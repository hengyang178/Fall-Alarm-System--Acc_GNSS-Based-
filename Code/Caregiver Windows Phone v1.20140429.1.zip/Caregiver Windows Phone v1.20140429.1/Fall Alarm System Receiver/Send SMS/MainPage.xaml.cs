﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Send_SMS.Resources;

using Microsoft.Phone.Tasks;

namespace Send_SMS
{
    public partial class MainPage : PhoneApplicationPage
    {

        string contextSMS;
        string latitudeNS;
        string longitudeEW;

        // Constructor
        public MainPage()
        {
            InitializeComponent();

            RadioButtonN.IsChecked = true;
            RadioButtonS.IsChecked = false;

            RadioButtonE.IsChecked = true;
            RadioButtonW.IsChecked = false;

            // Sample code to localize the ApplicationBar
            //BuildLocalizedApplicationBar();
        }

        private void ButtonSned_Click(object sender, RoutedEventArgs e)
        {
            // Get north/south, east/west information
            latitudeNS = (RadioButtonN.IsChecked == true) ? "N" : "S";
            longitudeEW = (RadioButtonE.IsChecked == true) ? "E" : "W";

            // Assemble context of SMS
            contextSMS = "Fall alarm from the elderly!\n\n";
            contextSMS = contextSMS + "Latitude:\n" + TextBoxLa.Text + "°" + latitudeNS + "\n";
            contextSMS = contextSMS + "Longitude:\n" + TextBoxLon.Text + "°" + longitudeEW + "\n\n";
            contextSMS = contextSMS + "Link:\n";
            contextSMS = contextSMS + "http://www.bing.com/maps/default.aspx?";
            contextSMS = contextSMS + "cp=" + TextBoxLa.Text + "~" + TextBoxLon.Text;
            contextSMS = contextSMS + "&lvl=18&style=r&v=2&where1=Fall_Location";

            // Send SMS
            SmsComposeTask smsComposeTask = new SmsComposeTask();
            //smsComposeTask.To = "+8613400000000";
            smsComposeTask.Body = contextSMS;
            smsComposeTask.Show();
        }

        private void RadioButtonLa_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void RadioButtonLon_Checked(object sender, RoutedEventArgs e)
        {

        }

        // Sample code for building a localized ApplicationBar
        //private void BuildLocalizedApplicationBar()
        //{
        //    // Set the page's ApplicationBar to a new instance of ApplicationBar.
        //    ApplicationBar = new ApplicationBar();

        //    // Create a new button and set the text value to the localized string from AppResources.
        //    ApplicationBarIconButton appBarButton = new ApplicationBarIconButton(new Uri("/Assets/AppBar/appbar.add.rest.png", UriKind.Relative));
        //    appBarButton.Text = AppResources.AppBarButtonText;
        //    ApplicationBar.Buttons.Add(appBarButton);

        //    // Create a new menu item with the localized string from AppResources.
        //    ApplicationBarMenuItem appBarMenuItem = new ApplicationBarMenuItem(AppResources.AppBarMenuItemText);
        //    ApplicationBar.MenuItems.Add(appBarMenuItem);
        //}
    }
}