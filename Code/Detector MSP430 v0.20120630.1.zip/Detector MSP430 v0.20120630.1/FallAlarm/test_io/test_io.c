/** 
 * \Project structure:
 * \    level 1: test_io.c
 * \    level 2: io.c
 */

#include <msp430x16x.h>
#include <in430.h>
#include <stdio.h>
#include "../Header Files/io.h"
#include "../Header Files/delay.h"

/**
 * \Clock initiation
 */
void init_Clock(){
  unsigned char i;
  BCSCTL1 = RSEL0 + RSEL1 + RSEL2;
  DCOCTL = DCO0 + DCO1 + DCO2;
  do {
    IFG1 &= ~OFIFG;
    for (i = 255; i > 0; i--);
  } while (IFG1 & OFIFG);
  BCSCTL2 = SELM1 + SELS;               // Choose XT2 for SMCLK, MCLK
}


void main(){
  WDTCTL = WDTPW + WDTHOLD;             // Stop WDT
  _DINT();                              // Disable interrupt, in in430.h
  init_Clock();
  init_IO();
  
  //show_LED_Quickly();
  //open_Inactive_Beeper();
  while(1) {
    if(scan_Button_S3())
      show_LED_Quickly();
    else;
  }
}