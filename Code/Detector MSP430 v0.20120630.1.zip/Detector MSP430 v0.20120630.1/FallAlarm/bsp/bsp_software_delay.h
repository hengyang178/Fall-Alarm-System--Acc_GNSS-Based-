/**
 * IAR Embedded Delay Function
 *
 */
#ifndef SOFTWARE_DELAY_H_
#define SOFTWARE_DELAY_H_

#define CPU_F ((double)8000000)   // ??MCLK=8MHZ
#define SW_delay_us(x) __delay_cycles((long)(CPU_F*(double)x/1000000.0))
#define SW_delay_ms(x) __delay_cycles((long)(CPU_F*(double)x/1000.0))
#define SW_delay_s(x) __delay_cycles((long)(CPU_F*(double)x/1.0))\

#endif /* SOFTWARE_DELAY_H_ */
