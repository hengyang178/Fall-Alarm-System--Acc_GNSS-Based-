#ifndef BEEPER_H_
#define BEEPER_H_
#include "bsp.h"
#include "bsp_software_delay.h"

#define         BEEPER_ON       P1OUT|=BIT2
#define         BEEPER_OFF      P1OUT&=~BIT2
#define 		BEEPER_MS(x) { BEEPER_ON; SW_delay_ms(x); BEEPER_OFF;}

#endif /* BEEPER_H_ */
