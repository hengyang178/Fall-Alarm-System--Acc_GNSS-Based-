#ifndef EEPROM_H_
#define EEPROM_H_

unsigned char test_EEPROM_IIC_Software();
unsigned char test_EEPROM_I2C_Software();
unsigned char test_EEPROM_I2C_Hardware();
unsigned char test_EEPROM_I2C();

#endif