/**
 * Define the default error codes used in the 1611 board
 * Error code is by default unsigned char type
 */
#ifndef ERROR_DEFINE_H_
#define ERROR_DEFINE_H_

#define FAIL					0xFF
#define SUCCESS 				0
/* EEPROM access error */
#define EEPROM_ADDR_ERROR 				0xFE
#define EEPROM_DATA_ERROR 				0xFD
#define EEPROM_MEMORY_ADDRESS_ERROR 	0xFC

/* e2prom phone book error */
#define PHONEBOOK_INDEX_ERROR			0xFB
#define PHONEBOOK_ADD_FULL				0xFA
#define PHONEBOOK_DEL_EMPTY				0xF9
#define PHONEBOOK_NUMBER_NO_EXIST		0xF8

/* flash phone book error */
#define FLASH_PHONEBOOK_COUNT_ERROR			0xFC
#define FLASH_PHONEBOOK_INDEX_ERROR 		0xFB
#define FLASH_PHONEBOOK_ADD_FULL			0xFA
#define FLASH_PHONEBOOK_DEL_EMPTY			0xF9
#define FLASH_PHONEBOOK_GET_EMPTY			0xF8
#define FLASH_PHONEBOOK_NUMBER_NO_EXIST		0xF7


#endif /* ERROR_DEFINE_H_ */
