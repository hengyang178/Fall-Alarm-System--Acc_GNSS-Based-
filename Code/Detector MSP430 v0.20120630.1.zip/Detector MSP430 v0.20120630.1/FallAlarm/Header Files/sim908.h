#ifndef   SIM908_H_
#define   SIM908_H_

extern unsigned char USART1_SMS_Received;
extern unsigned char USART1_SMS_Index[4];

void init_USART();
void powerOn_SIM908();
void powerDown_SIM908();
unsigned char get_Position();
unsigned char send_Alarm();
unsigned char test_GSM();
unsigned char operate_Phonebook();

#endif