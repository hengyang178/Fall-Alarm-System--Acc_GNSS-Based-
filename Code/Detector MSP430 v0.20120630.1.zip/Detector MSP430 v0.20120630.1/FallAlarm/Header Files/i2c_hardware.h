#ifndef   I2C_HARDWARE_H_
#define   I2C_HARDWARE_H_

unsigned char init_I2C_Hardware();
unsigned char write_Buffer_Hardware(unsigned char,
                                    unsigned char*, 
                                    unsigned char);
unsigned char read_Buffer_Hardware(unsigned char,
                                   unsigned char*,
                                   unsigned char,
                                   unsigned char*,
                                   unsigned char);

#endif