/**
 * Software I2C Driver
 */
#ifndef I2C_SOFTWARE_H_
#define I2C_SOFTWARE_H_

/**
 * \function I2C_init
 * \brief initialize software I2C
 */
void I2C_Init(void);

/**
 * \function I2C_Write_Byte
 * \brief write a byte via I2C
 * \param[in] addr: target I2C device address
 * \param[in] data: a byte to write
 * \return 0 for success
 */
unsigned char I2C_Write_Byte(unsigned char addr, unsigned char data);

/**
 * \function I2C_Write_Byte
 * \brief write a byte via I2C
 * \param[in] addr: target I2C device address
 * \param[out] data: memory to save the read byte
 * \return 0 for success
 */
unsigned char I2C_Read_Byte(unsigned char addr, unsigned char* data);

/**
 * \function I2C_Write_Buffer
 * \brief write multiple bytes via I2C
 * \param[in] addr: target I2C device address
 * \param[in] buffer: a pointer to data to send
 * \param[in] len: amount of bytes to send
 * \return 0 for success
 */
unsigned char I2C_Write_Buffer(unsigned char addr, unsigned char * buffer, unsigned int len);

/**
 * \function I2C_Read_Buffer
 * \brief read multiple bytes via I2C
 * \param[in] addr: target I2C device address
 * \param[out] buffer: memory to save the read bytes
 * \param[in] len: amount of bytes to receive
 * \return 0 for success
 */
unsigned char I2C_Read_Buffer(unsigned char addr, unsigned char * buffer, unsigned int len);

#endif /* I2C_DRIVER_H_ */
