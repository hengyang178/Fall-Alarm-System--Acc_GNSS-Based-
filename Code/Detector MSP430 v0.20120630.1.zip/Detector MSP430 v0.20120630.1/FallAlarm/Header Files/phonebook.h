#ifndef PHONEBOOK_H_
#define PHONEBOOK_H_

#define   PHONEBOOK_NUMBER_LENGTH_MAX   16
#define   PHONEBOOK_LENGTH_MAX          120

unsigned char copy_Phonebook(unsigned char *);
unsigned char add_One_Phone_Number(unsigned char *);
unsigned char delete_One_Phone_Number(unsigned char *);
unsigned char delete_All_Phone_Numbers();

#endif