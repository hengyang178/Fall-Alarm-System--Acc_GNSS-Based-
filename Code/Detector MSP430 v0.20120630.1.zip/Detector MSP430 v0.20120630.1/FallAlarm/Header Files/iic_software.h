#ifndef _IIC_SOFTWARE_H
#define _IIC_SOFTWARE_H

void init_IIC_Software();

unsigned char write_Single_Byte_Software(unsigned char, 
                                  unsigned char,
                                  unsigned char);
unsigned char write_Multiple_Byte_Software(unsigned char, 
                                  unsigned char,
                                  unsigned char *);
unsigned char read_Single_Byte_Software(unsigned char,
                                  unsigned char,
                                  unsigned char *);
unsigned char read_Multiple_Byte_Software(unsigned char, 
                                    unsigned char,
                                    unsigned char *);
unsigned char write_Buffer_Software(unsigned char,
                              unsigned char *,
                              unsigned char);
unsigned char read_Buffer_Software(unsigned char,
                              unsigned char *,
                              unsigned char,
                              unsigned char *,
                              unsigned char);

#endif