#ifndef USART_H_
#define USART_H_

unsigned char init_U0();
unsigned char init_U1();
unsigned char sendTo_U0(char *);

#endif