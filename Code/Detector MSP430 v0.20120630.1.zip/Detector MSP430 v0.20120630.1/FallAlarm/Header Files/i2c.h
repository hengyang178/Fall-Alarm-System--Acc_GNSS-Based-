/**
 * MSP430F1611 USART0 I2C mode
 * @author xutao.
 * @date 2011/09/24
 */
#ifndef I2C_H_
#define I2C_H_

/* 7bit I2C address. Pin(ALT ADDRESS) is connected to GND on 9DOF.*/
//#define ADXL345_ADDRESS 0x0053

/* 7bit I2C address. Pin(SDO) is connected to GND on 9DOF.*/
#define L3G4200D_ADDRESS 0x0068

void I2C_Init_Hardware(unsigned int address, unsigned char length);
void I2C_Set_Data_Length_Hardware(unsigned char length);
void I2C_Read_Hardware(unsigned char * byte, unsigned char length);
void I2C_Write_Hardware(unsigned char * byte, unsigned char length);

#endif
