#ifndef   ADXL345_H_
#define   ADXL345_H_

typedef struct{
  float x;
  float y;
  float z;
  float SVM;
}ACC;

extern ACC Acc;
extern unsigned char Flag_Fall;

unsigned char init_Timer_A();

unsigned char init_ADXL345();
unsigned char get_ADXL345_ID();
unsigned char get_Acceleration();

unsigned char init_ADXL345_Software();
unsigned char get_ADXL345_ID_Software();
unsigned char get_Raw_Acceleration_Software();

unsigned char detect_Falling(); // Fall detection algorithm

#endif