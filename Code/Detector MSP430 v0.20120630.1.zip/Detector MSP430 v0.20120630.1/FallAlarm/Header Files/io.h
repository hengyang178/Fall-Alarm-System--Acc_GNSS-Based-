#ifndef IO_H_
#define IO_H_

unsigned char init_IO();
unsigned char show_LED_Quickly();
unsigned char show_LED_Slowly();
unsigned char open_Active_Beeper();
unsigned char open_Inactive_Beeper();
unsigned char scan_Button_S3();
unsigned char scan_Button_S4();

#endif