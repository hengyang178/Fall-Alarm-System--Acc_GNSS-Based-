#ifndef FLASH_H_
#define FLASH_H_

unsigned char write_Byte(unsigned int, unsigned char *, unsigned char);
unsigned char erase_Segment(unsigned int);

#endif