/* Delay declaration for msp430 */

#ifndef DELAY_H_
#define DELAY_H_

#define   MCLK    8000000
// function __delay_cycles(long) is defined in in430.h
#define   delay_us(x)   __delay_cycles((long)MCLK * (double)x / 1000000.0)
#define   delay_ms(x)   __delay_cycles((long)MCLK * (double)x / 1000.0)
#define   delay_s(x)   __delay_cycles((long)MCLK * (double)x / 1.0)

#endif