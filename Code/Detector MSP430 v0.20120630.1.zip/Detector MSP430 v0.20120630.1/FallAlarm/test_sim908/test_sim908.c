/** 
 * \Project structure:
 * \    level 1: test_sim908.c
 * \    level 2: sim908.c
 * \    level 3: usart.c, io.c
 */

#include  <msp430x16x.h>
#include  <in430.h>
#include  <stdlib.h>
#include  "../Header Files/sim908.h"
#include  "../Header Files/delay.h"
#include  "../Header Files/io.h"

/** 
 * \Clock initiation
 */
void init_Clock(){
  unsigned char i;
  BCSCTL1 = RSEL0 + RSEL1 + RSEL2;
  DCOCTL = DCO0 + DCO1 + DCO2;
  do {
    IFG1 &= ~OFIFG;
    for (i = 255; i > 0; i--);
  } while (IFG1 & OFIFG);
  BCSCTL2 = SELM1 + SELS;               // Choose XT2 for SMCLK, MCLK
}

void main(){
  WDTCTL = WDTPW + WDTHOLD;             // Stop WDT
  _DINT();                              // Disable interrupt, in in430.h
  init_Clock();
  init_IO();
  init_USART();
  _EINT();                              // Enable interrupt
  
  powerOn_SIM908();
  
  //send_Alarm();
  
  test_GSM();
  get_Position();
  
  powerDown_SIM908();
  while(1)
    show_LED_Slowly();
}