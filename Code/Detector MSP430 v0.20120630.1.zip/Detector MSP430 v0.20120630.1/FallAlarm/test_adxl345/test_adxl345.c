/** 
 * \Project structure:
 * \    level 1: test_iic.c
 * \    level 2: adxl345.c, eeprom.c
 * \    level 3: i2c_hardware.c, i2c_software.c, iic_software.c, i2c.c, io.c,
 * \              usart.c
 */

#include <msp430x16x.h>
#include <in430.h>
#include <stdio.h>
#include "../Header Files/eeprom.h"
#include "../Header Files/adxl345.h"
#include "../Header Files/io.h"
#include "../Header Files/usart.h"

/**
 * \Clock initiation
 */
void init_Clock(){
  unsigned char i;
  BCSCTL1 = RSEL0 + RSEL1 + RSEL2;
  DCOCTL = DCO0 + DCO1 + DCO2;
  do {
    IFG1 &= ~OFIFG;
    for (i = 255; i > 0; i--);
  } while (IFG1 & OFIFG);
  BCSCTL2 = SELM1 + SELS;               // Choose XT2 for SMCLK, MCLK
}

void main(){
  WDTCTL = WDTPW + WDTHOLD;             // Stop WDT
  _DINT();                              // Disable interrupt, in in430.h
  init_Clock();
  init_IO();
  init_Timer_A();
  init_U0();
  _EINT();
  
  /* Test EEPROM on PCB v0.1 */
  //test_EEPROM_IIC_Software();
  //test_EEPROM_I2C_Software();
  //test_EEPROM_I2C_Hardware();
  //test_EEPROM_I2C();
  
  
  /* Test EEPROM on PCB v0.3 */
  init_ADXL345_Software();
  
  /*unsigned char ADXL345_ID;
  ADXL345_ID = get_ADXL345_ID();
  //ADXL345_ID = get_ADXL345_ID_Software();
  printf("Device ID: %x\n", ADXL345_ID);*/
  
  /*if(ADXL345_ID == 0xE5)
    show_LED_Slowly();
  else
    show_LED_Quickly();*/
  
  while(1){
    if(scan_Button_S4() == 1)
      show_LED_Quickly();
  }
}