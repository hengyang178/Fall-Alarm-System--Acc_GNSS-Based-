/** 
 * \The phonebook is set at segmentB(1000h~107Fh) in flash
 * \The maximal size of phonebook is 120 bytes(7 phone numbers)
 * \Phonebook strusture:
 * \                      Total number(1 byte) +
 * \                      Number length 1(1 byte), Phone number 1(16 byte) +
 * \                      Number length 2(1 byte), Phone number 2(16 byte) +
 * \                      ......
 * \                      Number length n(1 byte), Phone number n(16 byte)
 */

#include "../Header Files/phonebook.h"
#include "../Header Files/flash.h"
#include "../Header Files/usart.h"

#define   PHONEBOOK_TOTAL_NUMBER_MAX    7
#define   PHONEBOOK_START               0X1000

/**
 * \Copy the whole phonebook
 */
unsigned char copy_Phonebook(unsigned char *Phonebook){
  unsigned char *Ptr;
  Ptr = (unsigned char *) PHONEBOOK_START;
  
  unsigned char Count;
  for(Count = 0; Count < PHONEBOOK_LENGTH_MAX; Count ++)
    *(Phonebook ++) = *(Ptr ++);
  
  return 1;
}

/**
 * \Match a phone number in phonebook, return 1 when exists
 */
unsigned char match_Number(unsigned char *Phonebook,
                           unsigned char *Phone_Number)
{
  unsigned char Temp1,
                Temp2;
  
  for(Temp1 = 0; Temp1 < *Phonebook; Temp1 ++) {
    if(*(Phonebook + 1 + Temp1 * (PHONEBOOK_NUMBER_LENGTH_MAX + 1)) == \
      *Phone_Number)
    {
       for(Temp2 = 0; Temp2 < *Phone_Number; Temp2 ++) {
        if(*(Phonebook + 2 + Temp1 * (PHONEBOOK_NUMBER_LENGTH_MAX + 1) + \
          Temp2) != *(Phone_Number + Temp2 + 1))
          break;
       }
       if(Temp2 == *Phone_Number)
         return (Temp1 + 1);
    }
  }
  
  return 0;
}

/**
 * \Add a number to phonebook
 * \(1)Return 0 at below situations:
      Phonebook is full,
      Input phone number is too long,
      Input phone number is exist
* \(2)Structure of input phonenumber array:
      Number length 1(1 byte) + Phone number 1(x byte) + '#'(1 byte, not record)
 */
unsigned char add_One_Phone_Number(unsigned char *Phone_Number) {
  
  unsigned char *Ptr, Total_Number = 0;
  Ptr = (unsigned char *) PHONEBOOK_START;
  
  /* Check if the flash is not used yet */
  if(*Ptr == 0xFF)
    write_Byte(PHONEBOOK_START, &Total_Number, 1);
  
  /* Check if the phone number is too long */
  if(*(Phone_Number) > PHONEBOOK_NUMBER_LENGTH_MAX)
    return 0;
  
  /* Check if the phone number is already existing */
  unsigned char Phonebook[PHONEBOOK_LENGTH_MAX];
  copy_Phonebook(Phonebook);
  if(match_Number(Phonebook, Phone_Number))
    return 0;
  
  /* Check if the phonebook is full */
  Total_Number = *Ptr;
  if(Total_Number == PHONEBOOK_TOTAL_NUMBER_MAX)
    return 0;
  if(Total_Number > PHONEBOOK_TOTAL_NUMBER_MAX)
    Total_Number = 0;
  
  unsigned char temp = 0;
  while(temp <= *Phone_Number){
    Phonebook[(PHONEBOOK_NUMBER_LENGTH_MAX + 1) * Total_Number + 1 + temp] = \
      *(Phone_Number + temp);
    temp ++;
  }
  Phonebook[0] = ++ Total_Number;
  write_Byte(PHONEBOOK_START, Phonebook, PHONEBOOK_LENGTH_MAX);
  
  return 1;
}

/**
 * \Delete a number from phonebook
 * \(1)Return 0 at below situations:
      Phonebook is empty,
      Input phone number is too long(not right),
      Input phone number is not exist
* \(2)Structure of phonenumber array to delete:
      Number length 1(1 byte) + Phone number 1(x byte) + '#'(1 byte, not record)
 */
unsigned char delete_One_Phone_Number(unsigned char *Phone_Number) {
  
  unsigned char *Ptr, Total_Number = 0;
  Ptr = (unsigned char *) PHONEBOOK_START;
  
  /* Check the total number in phonebook*/
  if(*Ptr == 0)
    return 0;
  if(!((*Ptr >= 1) && (*Ptr <= 7))){
    write_Byte(PHONEBOOK_START, &Total_Number, 1);
    return 0;
  }
  
  /* Check if the phone number is too long */
  if(*(Phone_Number) > PHONEBOOK_NUMBER_LENGTH_MAX)
    return 0;
  
  /* Check if the phone number exists, and delete it */
  unsigned char Phonebook[PHONEBOOK_LENGTH_MAX], 
                Index;
  copy_Phonebook(Phonebook);
  Index = match_Number(Phonebook, Phone_Number);
  if(Index == 0)
    return 0;
  else if(Index == *Phonebook)
    Phonebook[0] --;
  else{
    unsigned char temp;
    for(; Index < *Phonebook; Index ++){
      for(temp = 0; temp < PHONEBOOK_NUMBER_LENGTH_MAX + 1; temp ++){
        Phonebook[(Index - 1) * (PHONEBOOK_NUMBER_LENGTH_MAX + 1) + 1 + temp] =\
          Phonebook[Index* (PHONEBOOK_NUMBER_LENGTH_MAX + 1) + 1 + temp];
      }
    }
    Phonebook[0] --;
  }
  
  write_Byte(PHONEBOOK_START, Phonebook, PHONEBOOK_LENGTH_MAX);
  return 1;
}

/**
 * \Delete all phone numbers
 */
unsigned char delete_All_Phone_Numbers() {
  
  unsigned char temp = 0;
  write_Byte(PHONEBOOK_START, &temp, 1);
  //erase_Segment(PHONEBOOK_START);
  
  return 1;
}