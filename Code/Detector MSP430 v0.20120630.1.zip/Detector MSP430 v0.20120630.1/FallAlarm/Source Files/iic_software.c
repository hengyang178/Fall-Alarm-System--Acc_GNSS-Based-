/*  IIC is based on simulative I/O operation instead of hardware interrupt */

#include <msp430x16x.h>
#include "../Header Files/iic_software.h"

#define SDA BIT1
#define SCL BIT3
#define setSDA    P3OUT |= SDA
#define clearSDA  P3OUT &= ~SDA
#define setSCL    P3OUT |= SCL
#define clearSCL  P3OUT &= ~SCL
#define SDAin     P3DIR &= ~SDA
#define SDAout    P3DIR |= SDA
#define readSDA   (P3IN & SDA)

#define DELAY_NUM 	5

/**
 *\Basic init
 */
void init_IIC_Software(){
  // Select P3.1,3 as general IO
  P3SEL &= ~SDA;
  P3SEL &= ~SCL;
  P3DIR |= SDA;
  P3DIR |= SCL;
}

/**
 * \function delay
 * \brief short time delay
 */
void delay() {
	unsigned char q0;
	for (q0 = 0; q0 < DELAY_NUM; q0 ++) {
		_NOP();
	}
}

/**
 *\Start signal
 *\(1)When SCL high, the change from high to low of SDA generate Start signal
 *\(2)SCL should be low at last, so the SDA can change freely
 */
void start(){
  SDAout;
  
  setSDA;
  delay();
  
  setSCL;
  delay();
  
  clearSDA;
  delay();
  
  clearSCL;
  delay();
}

/**
 *\Stop signal
 *\(1)When SCL high, the change from low to high of SDA generate Stop signal
 *\(2)SCL should be low at last, so the SDA can change freely
 */
void stop(){
  SDAout;
  
  clearSDA;
  delay();
  
  setSCL;
  delay();
  
  setSDA;
  delay();
  
  clearSCL;
  delay();
}

/**
 *\Acknowledge
 *\(1)Generate low at SDA
 */
void ack(){
  SDAout;
  
  clearSDA;
  delay();
  
  setSCL;
  delay();
  
  clearSCL;
  delay();
}

/**
 *\No acknowledge
 *\(1)Generate high at SDA
 */
void nack(){
  SDAout;
  
  setSDA;
  delay();
  
  setSCL;
  delay();
  
  clearSCL;
  delay();
}

/**
 *\Transmit a byte, return 0 if ACK signal is received
 */
unsigned char writeByte(unsigned char Data){
  unsigned char count, ack;
  // Write 8 bits
  SDAout;
  for(count = 0; count < 8; count ++){
    if((Data & 0x80) == 0)
      clearSDA;
    else
      setSDA;
    Data = Data << 1;
    delay();
    setSCL;
    delay();
    clearSCL;
    delay();
  }
  
  // Read ack signal
  SDAin;
  setSCL;
  delay();
  delay();
  ack = readSDA;
  clearSCL;
  delay();
  
  return ack;
}

/**
 *\Read a byte
 */
unsigned char readByte(){
  unsigned char count, temp, Data;
  // Read 8 bits
  Data = 0;
  SDAin;
  for(count = 0; count < 8; count ++){
    setSCL;
    Data <<= 1;
    temp = readSDA;
    if(temp)
      Data |= 0x01;
    else
      Data &= 0xfe;
    clearSCL;
    delay();
  }
  return Data;
}

/**
 *\Write buffer
 */
unsigned char write_Buffer_Software(unsigned char DeviceAddr,
                              unsigned char *Buffer_Out,
                              unsigned char Length_Out)
{
  start();
  
  if(writeByte(DeviceAddr + 0x00))
    return 0;
  
  while(Length_Out --) {
    if(writeByte(*Buffer_Out))
      return 0;
    Buffer_Out ++;
  }
  
  stop();
  return 1;
}

/**
 *\Read buffer
 */
unsigned char read_Buffer_Software(unsigned char DeviceAddr,
                                   unsigned char *Buffer_Out,
                                   unsigned char Length_Out,
                                   unsigned char *Buffer_In,
                                   unsigned char Length_In)
{
  unsigned char temp = 0;
  
  start();
  
  if(writeByte(DeviceAddr + 0x00))
    return 0;
  
  while(Length_Out --) {
    if(writeByte(*Buffer_Out))
      return 0;
    Buffer_Out ++;
  }
  
  start();
  
  if(writeByte(DeviceAddr + 0x01))
    return 0;
  
  while(temp != Length_In){
    *(Buffer_In + temp) = readByte();
    temp ++;
    if(temp == Length_In)
      nack();
    else
      ack();
  }
  
  stop();
  return 1;
}