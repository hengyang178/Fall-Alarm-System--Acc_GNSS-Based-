/**
 * MSP430F1611 USART0 I2C mode.
 * I2C Master.
 * read or write in the polling way.
 * @author xutao.
 * @date 2011/09/24
 */

#include "../bsp/bsp.h"
#include "../Header Files/i2c.h"

/**
 * \function I2C_Init_Hardware
 * \brief initialize hardware i2c.
 * \param[in] address: 7-bit i2c slave address
 * \param[in] length: read or wirte byte length
 */
void I2C_Init_Hardware(unsigned int address, unsigned char length) {
	/* Select I2C(USART0) Pins */
	P3SEL |= 0x0A;

	/* Recommended init procedure */
	U0CTL |= I2C + SYNC;
        U0CTL &= ~CHAR;
	U0CTL &= ~I2CEN;

	/* SMCLK*/
	I2CTCTL |= I2CSSEL1;

	/* Write length of bytes */
	I2CNDAT = length;

	/* Slave Address */
	I2CSA = address;

	/*
	 * interrupt is Not Used in this mode.
	 * by xt.
	 * Enable RXRDYIFG interrupt
	 */
	//I2CIE = TXRDYIE;
	/* Enable I2C */
	U0CTL |= I2CEN;

	/* Enable interrupts */
	//_EINT();
}

/**
 * \function I2C_Set_Data_Length_Hardware
 * \brief set read or write data length.
 * \param[in] length: read or wirte byte length
 */
void I2C_Set_Data_Length_Hardware(unsigned char length) {
	while ((I2CIFG & ARDYIFG) == 0)
		;

	I2CNDAT = length;
}

/**
 * \function I2C_Read_Hardware
 * \brief read bytes.
 * \param[out] byte: the pointer to data
 * \param[in] length: read byte length
 */
void I2C_Read_Hardware(unsigned char * byte, unsigned char length) {
	U0CTL |= MST; // Master mode
	I2CTCTL = I2CSTT + I2CSTP; // Initiate transfer
	while (length--) {
		while ((I2CIFG & RXRDYIFG) == 0)
			; // Wait for Receiver to be ready
		*byte = I2CDRB; // Receive Byte from Slave
		byte++;
	}
	while ((I2CTCTL & I2CSTP) == 0x02)
		; // Wait for Stop Condition
}

/**
 * \function I2C_Write_Hardware
 * \brief write bytes.
 * \param[out] byte: the pointer to data
 * \param[in] length: write byte length
 */
void I2C_Write_Hardware(unsigned char * byte, unsigned char length) {
	U0CTL |= MST; // Master mode
	I2CTCTL |= I2CSTT + I2CSTP + I2CTRX; // Initiate transfer
	while (length--) {
		while ((I2CIFG & TXRDYIFG) == 0)
			; // Wait for transmitter to be ready
		I2CDRB = *byte; // Load  I2CDRB
		byte++;
	}
	while ((I2CTCTL & I2CSTP) == 0x02)
		; // Wait for Stop Condition
}
