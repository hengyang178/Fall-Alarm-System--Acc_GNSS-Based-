#include  <msp430x16x.h>
#include  <string.h>
#include  "../Header Files/sim908.h"
#include  "../Header Files/usart.h"
#include  "../Header Files/delay.h"
#include  "../Header Files/phonebook.h"
#include  "../Header Files/io.h"

#define   USART1_DATA_RECEIVED_LENGTH_MAX     200
#define   LATITUDE_LENGTH_MAX                 11
#define   LONGITUDE_LENGTH_MAX                12
#define   POSITION_COUNT_MAX                  255

#define   SMS_ADD                     '0'
#define   SMS_DEL                     '1'
#define   SMS_DEL_ALL                 '2'


// Template to match
enum{Match_OK,
      Match_CREG,
      Match_CGATT,
      Match_CMGR,
      Match_SMS_COMMAND};
struct{
  unsigned char *String;
  unsigned char Length;
}Template[] = {{"OK",2},
                {"+CREG: 0,1",10},
                {"+CGATT: 1",9},
                {"+CMGR:",6},
                {"SMS_COMMAND=",12}};

// Position struct
struct{
  char Latitude[15];
  char La_Indicator[2];
  char Longitude[15];
  char Lon_Indicator[2];
}Position;

// USART1 data buffer and others
char *USART1_Data_toSend;
unsigned char USART1_Data_Received[ USART1_DATA_RECEIVED_LENGTH_MAX ] = {0};
unsigned char USART1_Data_Received_Length = 0;
unsigned char USART1_SMS_Count = 0;
unsigned char USART1_SMS_Index[4];
unsigned char USART1_SMS_Received = 0;

// USART0 data buffer and others
unsigned char USART0_Data_Received;
unsigned char USART0_Data_Received_Index = 0;
unsigned char USART0_Data_Received_Comma = 0;
unsigned char USART0_Data_Received_Fixed = 0;
unsigned char USART0_Data_Received_GPGGA = 0;

// Number of times to read the GPS info
unsigned char Position_Count = POSITION_COUNT_MAX;

/**
 * \USART initiation
 */
void init_USART(){
  init_U1();
  init_U0();
}

/**
 * \Power on SIM908
 */
void powerOn_SIM908(){
  delay_s(2.0);
  P4OUT &= 0xfe;            // P4.0 output 0
  delay_s(1.3);
  P4OUT |= 0x01;            // P4.0 output 1
  delay_s(5.0);
}

/**
 * \Power down SIM908
 */
void powerDown_SIM908(){
  delay_s(2.0);
  P4OUT &= 0xfe;            // P4.0 output 0
  delay_s(1.3);
  P4OUT |= 0x01;            // P4.0 output 1
  delay_s(5.0);
}

/**
 * \Send a string to SIM908
 */
unsigned char sendTo_U1(char *String){
  USART1_Data_Received_Length = 0;
  IFG2 |= UTXIFG1;
  while(1){
    if(*String == '#')
      break;
    while(!(IFG2 & UTXIFG1));
    U1TXBUF = *String;
    String ++;
  }
  return 1;
}

/** 
 * \Match USART received string and template string
 * \Return 0 when not match
 * \Start is the start byte of USART string
 * \If Function_Flag == 0, match USART1 received string, else USART0
 * \Template_No is the number of template to match
 */
unsigned char match_String(unsigned char Template_No){
  unsigned char temp1 = 0, 
                temp2 = 0,
                temp3 = 0;
  while(temp1 < USART1_Data_Received_Length){
    if(USART1_Data_Received[ temp1 ] == \
      *(Template[Template_No].String + temp2)){
      temp1 ++;
      temp2 ++;
    }
    else{
      temp3 ++;
      temp1 = temp3;
      temp2 = 0;
    }
    if(temp2 == Template[Template_No].Length)
      return (temp3 + 1);
  }
  return 0;
}

/**
 * \Test the GSM network
 */
unsigned char test_GSM() {
  char String[50];
    
  /* AT */
  strcpy(String,"AT\r#");
  do{
    sendTo_U1(String);
    delay_s(1);
  }while(!match_String(Match_OK));
  
  /* AT+CSQ */
  strcpy(String,"AT+CSQ\r#");
  do{
    sendTo_U1(String);
    delay_s(1);
  }while(!match_String(Match_OK));
  
  /* AT+CREG? */
  strcpy(String,"AT+CREG?\r#");
  do{
    sendTo_U1(String);
    delay_s(1);
  }while(!match_String(Match_CREG));
  
  /* AT+CGATT? */
  strcpy(String,"AT+CGATT?\r#");
  do{
    sendTo_U1(String); 
    delay_s(2);
  }while(!match_String(Match_CGATT));
  
  return 1;
}

/**
 * \Get the position info
 */
unsigned char get_Position(){
  char String[50];
  
  /* AT+CGPSPWR=1  */
  strcpy(String,"AT+CGPSPWR=1\r#");
  do{
    sendTo_U1(String);
    delay_ms(100);
  }while(!match_String(Match_OK));
  
  /* AT+CGPSRST=1, reset GPS in autonomy mode */
  strcpy(String,"AT+CGPSRST=1\r#");
  do{
    sendTo_U1(String);
    delay_ms(100);
  }while(!match_String(Match_OK));
  
  /* Output whole NMEA info  */
  strcpy(String,"AT+CGPSOUT=255\r#");
  do{
    sendTo_U1(String);
    delay_ms(100);
  }while(!match_String(Match_OK));
  
  /* (For test) Loop with no end */
  while(1);
  
  /* Loop to read numeric GPS datas */
  //while((Position_Count > 0) && (USART0_Data_Received_Fixed == 0));
  
  /* AT+CGPSPWR=0, shut down GPS module */
  strcpy(String,"AT+CGPSPWR=0\r#");
  do{
    sendTo_U1(String);
    delay_ms(100);
  }while(!match_String(Match_OK));
  
  /* (For test) Output position to USART0 */
  /*if(USART0_Data_Received_Fixed == 1){
    strcpy(String,"\r\nLatitude: #");
    sendTo_U0(String);
    
    strcpy(String, Position.Latitude);
    sendTo_U0(String);
    
    strcpy(String,", #");
    sendTo_U0(String);
    
    strcpy(String, Position.La_Indicator);
    sendTo_U0(String);
    
    strcpy(String,"\r\nLongitude: #");
    sendTo_U0(String);
    
    strcpy(String, Position.Longitude);
    sendTo_U0(String);
    
    strcpy(String,", #");
    sendTo_U0(String);
    
    strcpy(String, Position.Lon_Indicator);
    sendTo_U0(String);
  }
  else{
    strcpy(String,"\r\nPosition is not fixed!\r\n#");
    sendTo_U0(String);
  }*/
  
  return 1;
}

/**
 * \Send alarm SMS
 */
unsigned char send_Alarm(){
  char String[50];
  
  /* Test the GSM network */
  test_GSM();
  
  /* Get position info */
  //get_Position();
  
  /* AT+CMGF=1 */
  strcpy(String,"AT+CMGF=1\r#");
  do{
    sendTo_U1(String);
    delay_s(1);
  }while(!match_String(Match_OK));
  
  /* AT+CMGS=xxxxxxxxxxx */
  strcpy(String,"AT+CMGS=\"+8613401161233\"\r#");
  sendTo_U1(String);
  delay_ms(500);
  
  /* Alarm and position */
  strcpy(String,"Alarm!#");
  sendTo_U1(String);
  
  if(USART0_Data_Received_Fixed == 1){
    strcpy(String,"\rLatitude: #");
    sendTo_U1(String);
    
    strcpy(String, Position.Latitude);
    sendTo_U1(String);
    
    strcpy(String,", #");
    sendTo_U1(String);
    
    strcpy(String, Position.La_Indicator);
    sendTo_U1(String);
    
    strcpy(String,"\rLongitude: #");
    sendTo_U1(String);
    
    strcpy(String, Position.Longitude);
    sendTo_U1(String);
    
    strcpy(String,", #");
    sendTo_U1(String);
    
    strcpy(String, Position.Lon_Indicator);
    sendTo_U1(String);
    
    while(!(IFG2 & UTXIFG1));
    U1TXBUF = 26;
  }
  else{
    strcpy(String,"\rPosition is not fixed!#");
    sendTo_U1(String);
    
    while(!(IFG2 & UTXIFG1));
    U1TXBUF = 26;
  }
  while(!match_String(Match_OK));
  
  /* (For test) output typical alarm SMS */
  /*strcpy(String, "Alarm! #");
  sendTo_U1(String);
  strcpy(String, "\rLatitude: 39.58738963,N #");
  sendTo_U1(String);
  strcpy(String, "\rLongitude: 116.20748433,E#");
  sendTo_U1(String);
  while(!(IFG2 & UTXIFG1));
  U1TXBUF = 26;
  while(!match_String(Match_OK));*/
  
  return 1;
}

/**
 * \Operate flash phonebook
 * \SMS Strings is ADD, DEL and DEL_ALL
 * \The format of ADD is: SMS_COMMAND=0#xxxxxxxxxxx#
 * \The format of DEL is: SMS_COMMAND=1#xxxxxxxxxxx#
 * \The format of DEL_ALL is: SMS_COMMAND=2
 */
unsigned char operate_Phonebook() {
  unsigned char Temp;
  char String[50];
  
  /* AT+CMGR=xxx */
  delay_s(3);
  //strcpy(String, "AT+CMGR=1\r#");
  strcpy(String, "AT+CMGR=");
  for(Temp = 0; (Temp < 4) && (USART1_SMS_Index[Temp] != '\r'); Temp ++)
    String[8 + Temp] = USART1_SMS_Index[Temp];
  String[8 + Temp] = '\r';
  String[8 + Temp + 1] = '#';
  sendTo_U1(String);
  while(!match_String(Match_OK));
  
  /* Recognize SMS String */
  if(Temp = match_String(Match_SMS_COMMAND)) {
    unsigned char Length = Template[Match_SMS_COMMAND].Length,
                  Index,
                  Phone_Number[PHONEBOOK_NUMBER_LENGTH_MAX + 2];
    
    /* (For test) Output phonebook content before operation */
    unsigned char phonebook[PHONEBOOK_LENGTH_MAX];
    copy_Phonebook(phonebook);
    strcpy(String, "\r\n\r\nPhonebook before operation :\r\n\r\n#");
    sendTo_U0(String);
    
    if((phonebook[0] >= 0) && (phonebook[0] <= 7)) {
      strcpy(String, "\tTotal number = #");
      sendTo_U0(String);
      String[0] = phonebook[0] + 0x30;
      String[1] = '\r';
      String[2] = '\n';
      String[3] = '#';
      sendTo_U0(String);
    }
    else if(phonebook[0] == 0xFF) {
      strcpy(String, "\tNot used!\r\n#");
      sendTo_U0(String);
    }
    else {
      strcpy(String, "\tPhonebook error!\r\n#");
      sendTo_U0(String);
    }
    
    switch(USART1_Data_Received[Temp + Length - 1]) {
    // Add one phone number
    case SMS_ADD:
      for(Index = 0; USART1_Data_Received[Temp + Length + 1 + Index] != '#'; 
      Index ++)
      {
        if(Temp + Length + 1 + Index == USART1_Data_Received_Length - 1)
          return 0;
        else if(Index == PHONEBOOK_NUMBER_LENGTH_MAX)
          return 0;
        Phone_Number[Index + 1] = \
          USART1_Data_Received[Temp + Length + 1 + Index];
      }
      Phone_Number[Index + 1] = '#';
      Phone_Number[0] = Index;            // Record the length of number
      
      if(!add_One_Phone_Number(Phone_Number)) {
        strcpy(String, "\r\n\r\nOperation wrong!\r\n#");
        sendTo_U0(String);
      }
      else {
        strcpy(String, "\r\n\r\nOperation success!\r\n#");
        sendTo_U0(String);
      }
      
      break;
      
      // Delete one phone number
    case SMS_DEL:
      for(Index = 0; USART1_Data_Received[Temp + Length + 1 + Index] != '#'; 
      Index ++)
      {
        if(Temp + Length + 1 + Index == USART1_Data_Received_Length - 1)
          return 0;
        else if(Index == PHONEBOOK_NUMBER_LENGTH_MAX)
          return 0;
        Phone_Number[Index + 1] = \
          USART1_Data_Received[Temp + Length + 1 + Index];
      }
      Phone_Number[Index + 1] = '#';
      Phone_Number[0] = Index;            // Record the length of number
      
      if(!delete_One_Phone_Number(Phone_Number)) {
        strcpy(String, "\r\n\r\nOperation wrong!\r\n#");
        sendTo_U0(String);
      }
      else {
        strcpy(String, "\r\n\r\nOperation success!\r\n#");
        sendTo_U0(String);
      }
      
      break;
      
      // Delete all numbers
    case SMS_DEL_ALL:
      delete_All_Phone_Numbers();
      break;
      
    default:
      break;
    }
    
    /* (For test) Output phonebook content after operation */
    copy_Phonebook(phonebook);
    strcpy(String, "\r\n\r\nPhonebook after operation :\r\n\r\n#");
    sendTo_U0(String);
    strcpy(String, "\tTotal number = #");
    sendTo_U0(String);
    String[0] = phonebook[0] + 0x30;
    String[1] = '\r';
    String[2] = '\n';
    String[3] = '\r';
    String[4] = '\n';
    String[5] = '#';
    sendTo_U0(String);
    unsigned char temp1, temp2;
    for(temp1 = 0; temp1 < phonebook[0]; temp1 ++){
      strcpy(String, "Number x: #");
      String[7] = temp1 + 0x31;
      for(temp2 = 0; temp2 < phonebook[1 + temp1 * 17]; temp2 ++){
        String[10 + temp2] = phonebook[2 + temp2 + temp1 * 17];
      }
      String[10 +temp2] = '\r';
      String[11 +temp2] = '\n';
      String[12 +temp2] = '\r';
      String[13 +temp2] = '\n';
      String[14 +temp2] = '#';
      sendTo_U0(String);
    }
  }
  
  /* Delete all SMS: AT+CMGD=1,4 */
  strcpy(String, "AT+CMGD=1,4\r#");
  sendTo_U1(String);
  
  return 1;
}

/**
 * \Receive a byte from GSM port of SIM908
 * \Match the string "+CMTI:" to decide if it's a received SMS
 * \USART1_SMS_Index[x] used to record the SMS index number
 */
#pragma vector = USART1RX_VECTOR
__interrupt void USART1_RX_ISR(){
  USART1_Data_Received[ USART1_Data_Received_Length ] = U1RXBUF;
  
  while(!(IFG1 & UTXIFG0));
  U0TXBUF = USART1_Data_Received[ USART1_Data_Received_Length ];
  
  /* The switch used to decide if had received a SMS */
  switch(USART1_SMS_Count){
  case 0:
    if(USART1_Data_Received[ USART1_Data_Received_Length ] == '+')
      USART1_SMS_Count ++;
    break;
    
  case 1:
    if(USART1_Data_Received[ USART1_Data_Received_Length ] == 'C')
      USART1_SMS_Count ++;
    else{
      USART1_SMS_Count = 0;
    }
    break;
    
  case 2:
    if(USART1_Data_Received[ USART1_Data_Received_Length ] == 'M')
      USART1_SMS_Count ++;
    else{
      USART1_SMS_Count = 0;
    }
    break;
    
  case 3:
    if(USART1_Data_Received[ USART1_Data_Received_Length ] == 'T')
      USART1_SMS_Count ++;
    else{
      USART1_SMS_Count = 0;
    }
    break;
    
  case 4:
    if(USART1_Data_Received[ USART1_Data_Received_Length ] == 'I')
      USART1_SMS_Count ++;
    else{
      USART1_SMS_Count = 0;
    }
    break;
    
  case 5:
    if(USART1_Data_Received[ USART1_Data_Received_Length ] == ':')
      USART1_SMS_Count ++;
    else{
      USART1_SMS_Count = 0;
    }
    break;
    
  case 6:
    if(USART1_Data_Received[ USART1_Data_Received_Length ] == ' ')
      USART1_SMS_Count ++;
    else{
      USART1_SMS_Count = 0;
    }
    break;
    
  case 7:
    if(USART1_Data_Received[ USART1_Data_Received_Length ] == '\"')
      USART1_SMS_Count ++;
    else{
      USART1_SMS_Count = 0;
    }
    break;
    
  case 8:
    if(USART1_Data_Received[ USART1_Data_Received_Length ] == 'S')
      USART1_SMS_Count ++;
    else{
      USART1_SMS_Count = 0;
    }
    break;
    
  case 9:
    if(USART1_Data_Received[ USART1_Data_Received_Length ] == 'M')
      USART1_SMS_Count ++;
    else{
      USART1_SMS_Count = 0;
    }
    break;
    
  case 10:
    if(USART1_Data_Received[ USART1_Data_Received_Length ] == '\"')
      USART1_SMS_Count ++;
    else{
      USART1_SMS_Count = 0;
    }
    break;
    
  case 11:
    if(USART1_Data_Received[ USART1_Data_Received_Length ] == ',')
      USART1_SMS_Count ++;
    else{
      USART1_SMS_Count = 0;
    }
    break;
    
  case 12:
    if((USART1_SMS_Index[0] = \
      USART1_Data_Received[ USART1_Data_Received_Length ]) != '\r')
      USART1_SMS_Count ++;
    else;
    break;
    
  case 13:
    if((USART1_SMS_Index[1] = \
      USART1_Data_Received[ USART1_Data_Received_Length ]) != '\r')
      USART1_SMS_Count ++;
    else{
      USART1_SMS_Count = 0;
      USART1_SMS_Received = 1;
    }
    break;
    
  case 14:
    if((USART1_SMS_Index[2] = \
      USART1_Data_Received[ USART1_Data_Received_Length ]) != '\r')
      USART1_SMS_Count ++;
    else{
      USART1_SMS_Count = 0;
      USART1_SMS_Received = 1;
    }
    break;
    
  case 15:
    USART1_SMS_Count = 0;
    USART1_SMS_Received = 1;
    USART1_SMS_Index[3] = '\r';
    break;
    
  default:
    break;
  }
    
  USART1_Data_Received_Length ++;
  if(USART1_Data_Received_Length == USART1_DATA_RECEIVED_LENGTH_MAX)
    USART1_Data_Received_Length = 0;
}

/**
 * \Receive a byte from GPS port of SIM908, record the position info
 * \This programme is based on NMEA format
 */
#pragma vector = USART0RX_VECTOR
__interrupt void USART0_RX_ISR(){
  USART0_Data_Received = U0RXBUF;
  
  while(!(IFG1 & UTXIFG0));
  U0TXBUF = USART0_Data_Received;
  
  /* The switch used to get $GPGGA line from NMEA */
  switch (USART0_Data_Received_GPGGA) {
  case 0:
    if(USART0_Data_Received == '$')
      USART0_Data_Received_GPGGA ++;
    break;
    
  case 1:
    if(USART0_Data_Received == 'G')
      USART0_Data_Received_GPGGA ++;
    else
      USART0_Data_Received_GPGGA = 0;
    break;
    
  case 2:
    if(USART0_Data_Received == 'P')
      USART0_Data_Received_GPGGA ++;
    else
      USART0_Data_Received_GPGGA = 0;
    break;
    
  case 3:
    if(USART0_Data_Received == 'G')
      USART0_Data_Received_GPGGA ++;
    else
      USART0_Data_Received_GPGGA = 0;
    break;
    
  case 4:
    if(USART0_Data_Received == 'G')
      USART0_Data_Received_GPGGA ++;
    else
      USART0_Data_Received_GPGGA = 0;
    break;
    
  case 5:
    if(USART0_Data_Received == 'A')
      USART0_Data_Received_GPGGA ++;
    else
      USART0_Data_Received_GPGGA = 0;
    break;
    
  default:
    break;
  }
  
  /* The next programme used to get effective position info */
  if(USART0_Data_Received_GPGGA == 6) {
    switch (USART0_Data_Received_Comma) {
    case 0:
      if(USART0_Data_Received == ',')
        USART0_Data_Received_Comma ++;
      break;
      
    case 1:
      if(USART0_Data_Received == ','){
        USART0_Data_Received_Comma ++;
        USART0_Data_Received_Index = 0;
      }
      break;
      
    case 2:
      if(USART0_Data_Received == ','){
        USART0_Data_Received_Comma ++;
        Position.Latitude[USART0_Data_Received_Index] = '#';
        USART0_Data_Received_Index = 0;
      }
      else if (USART0_Data_Received_Index < LATITUDE_LENGTH_MAX)
        Position.Latitude[USART0_Data_Received_Index ++] = \
          USART0_Data_Received;
      else;
      break;
      
    case 3:
      if(USART0_Data_Received == ','){
        if(USART0_Data_Received_Index == 0)
          Position.La_Indicator[0] = '#';
        USART0_Data_Received_Comma ++;
        Position.La_Indicator[1] = '#';
      }
      else
        Position.La_Indicator[0] = USART0_Data_Received;
      break;
      
    case 4:
      if(USART0_Data_Received == ','){
        USART0_Data_Received_Comma ++;
        Position.Longitude[USART0_Data_Received_Index] = '#';
        USART0_Data_Received_Index = 0;
      }
      else if (USART0_Data_Received_Index < LONGITUDE_LENGTH_MAX)
        Position.Longitude[USART0_Data_Received_Index ++] = \
          USART0_Data_Received;
      else;
      break;
      
    case 5:
      if(USART0_Data_Received == ','){
        if(USART0_Data_Received_Index == 0)
          Position.Lon_Indicator[0] = '#';
        USART0_Data_Received_Comma ++;
        Position.Lon_Indicator[1] = '#';
      }
      else
        Position.Lon_Indicator[0] = USART0_Data_Received;
      break;
      
    case 6:
      if(USART0_Data_Received == '1'){
        USART0_Data_Received_Comma = 0;
        USART0_Data_Received_GPGGA = 0;
        USART0_Data_Received_Fixed = 1;
        IE1 &= ~URXIE0;
      }
      else{
        USART0_Data_Received_Comma = 0;
        USART0_Data_Received_GPGGA = 0;
        if((-- Position_Count) == 0)
          IE1 &= ~URXIE0;
      }
      break;
      
    default:
      break;
    }
  }
}