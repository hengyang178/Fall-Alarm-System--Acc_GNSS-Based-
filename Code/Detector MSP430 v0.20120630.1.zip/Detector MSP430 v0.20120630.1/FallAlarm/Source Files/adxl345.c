/* ADXL345 operation */

#include <msp430x16x.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "../Header Files/adxl345.h"
#include "../Header Files/i2c_hardware.h"
#include "../Header Files/iic_software.h"
#include "../Header Files/i2c_software.h"
#include "../Header Files/usart.h"
#include "../Header Files/io.h"

/*
* \ADXL345 register
*/
#define   ADXL345_DEVICE_ADDRESS_7        0x53
#define   ADXL345_DEVICE_ADDRESS_8        0xA6

#define   ADXL345_REGISTER_DEVICE_ID      0x00

#define   ADXL345_REGISTER_OSFX           0x1E
#define   ADXL345_REGISTER_OSFY           0x1F
#define   ADXL345_REGISTER_OSFZ           0x20
#define ADXL345_REGISTER_DUR 0x21
#define ADXL345_REGISTER_LATENT 0x22
#define ADXL345_REGISTER_WINDOW 0x23

#define   ADXL345_REGISTER_BW_RATE        0x2C
#define   ADXL345_REGISTER_POWER_CTL      0x2D
#define   ADXL345_REGISTER_INT_ENABLE     0x2E
#define   ADXL345_REGISTER_INT_MAP        0x2F

#define   ADXL345_REGISTER_DATA_FORMAT    0x31
#define   ADXL345_REGISTER_DATAX0         0x32
#define   ADXL345_REGISTER_DATAX1 0x33
#define   ADXL345_REGISTER_DATAY0 0x34
#define   ADXL345_REGISTER_DATAY1 0x35
#define   ADXL345_REGISTER_DATAZ0 0x36
#define   ADXL345_REGISTER_DATAZ1 0x37

#define   ADXL345_DATA_RESOLUTION   0.004 // 4mg/LSB

/*
 * \Declaration of fall detection algorithm
 * (1)L means lower threshold, U means upper thereshold
 * (2)A means resultant acceleration, AX means acceleration in X-Axis
 * (3)There are five periods in fall processing:
      period 1: Free fall;
      period 2: Transition between free fall and impact;
      period 3: Impact;
      period 4: Transition between impact and inactivity;
      period 5: Inactivity.
*/
/* State */
#define   ACTIVITY        1
#define   INACTIVITY      2 // State contains period 5
#define   FREE_FALL       3 // Period 1
#define   IMPACT          4 // Period 3
#define   TRANSITION      5 // State corresponds to period 2 and 4
unsigned char State = INACTIVITY;

/* Acceleration threshold */
#define   GRAVITY                 1.0 //1g
#define   T_L_A_1                 0.6 //0.6g
#define   T_U_A_3                 2.7 //2.7g
#define   T_U_A_5                 2.0
#define   T_L_A_5                 0.5
#define   T_U_AX_5                +0.5
#define   T_L_AX_5                -0.5

/* Time threshold */
#define   T_U_TIME_1              100  // 1s
#define   T_U_TIME_2              200 // 2s
#define   T_U_TIME_3              100  // 1s
#define   T_U_TIME_4              200 // 2s
#define   T_U_TIME_5              100 // 1s
/* Time counter. when Time = 1, it means 10ms */
unsigned int Time = 0;

/* Flag of to assist algorithm */
unsigned char Flag_Free_Fall = 0;
unsigned char Flag_Impact = 0;
unsigned char Flag_Fall = 0;

/* struct of acceleration */
ACC Acc;

char String[50];

/**
* \Initiate Timer A
*/
unsigned char init_Timer_A() {
  //TACTL = TASSEL_1 + MC_1 + TACLR; // ACLK; no division; up mode
  TACTL = TASSEL_2 + ID_3 + MC_1 + TACLR; //SMCLK; 8 division; up mode
  TACCTL0 = CCIE; // enable interrupt
  //CCR0 = 32768; // 1Hz
  TACCR0 = 10000; // 100Hz, 10ms
  
  return 1;
}

/**
* \Initiate ADXL345
*/
unsigned char init_ADXL345(){
  
  init_I2C_Hardware();
  
  unsigned char Data_Out[2];
  
  /* Data format: 
  * (1)full resolution, 4mg/LSB
  * (2)-16g ~ +16g
  * (3)right justified
  */
  Data_Out[0] = ADXL345_REGISTER_DATA_FORMAT;
  Data_Out[1] = 0x2B;
  write_Buffer_Hardware(ADXL345_DEVICE_ADDRESS_7, Data_Out, 2);
  
  /* BW rate: 
  * (1)100Hz
  */
  Data_Out[0] = ADXL345_REGISTER_BW_RATE;
  Data_Out[1] = 0x0A;
  write_Buffer_Hardware(ADXL345_DEVICE_ADDRESS_7, Data_Out, 2);
  
  /* Power control: 
  * (1)measurement mode
  * (2)link activity and inactivity function
  */
  Data_Out[0] = ADXL345_REGISTER_POWER_CTL;
  Data_Out[1] = 0x28;
  write_Buffer_Hardware(ADXL345_DEVICE_ADDRESS_7, Data_Out, 2);
  
  /* INT enable: 
  * (1)disable INT
  */
  Data_Out[0] = ADXL345_REGISTER_INT_ENABLE;
  Data_Out[1] = 0x00;
  write_Buffer_Hardware(ADXL345_DEVICE_ADDRESS_7, Data_Out, 2);
  
  /* INT map: 
  * (1)no seting
  */
  Data_Out[0] = ADXL345_REGISTER_INT_MAP;
  Data_Out[1] = 0x00;
  write_Buffer_Hardware(ADXL345_DEVICE_ADDRESS_7, Data_Out, 2);
  
  return 1;
}

/**
* \Get ADXL345 device ID
*/
unsigned char get_ADXL345_ID() {
  unsigned char Data_Out = ADXL345_REGISTER_DEVICE_ID;
  unsigned char Data_In;
  
  init_I2C_Hardware();
  read_Buffer_Hardware(ADXL345_DEVICE_ADDRESS_7,
                       &Data_Out,
                       1,
                       &Data_In,
                       1);
  
  return Data_In;
}

/**
* \Get acceleration data
*/
unsigned char get_Acceleration() {
  unsigned char Data_Out = ADXL345_REGISTER_DATAX0;
  unsigned char Data_In[6];
  int Raw_Acc[3];
  
  read_Buffer_Hardware(ADXL345_DEVICE_ADDRESS_7,
                       &Data_Out,
                       1,
                       Data_In,
                       6);
  Raw_Acc[0] = Data_In[0];
  Raw_Acc[0] +=(Data_In[1] << 8);
  Raw_Acc[1] = Data_In[2];
  Raw_Acc[1] +=(Data_In[3] << 8);
  Raw_Acc[2] = Data_In[4];
  Raw_Acc[2] +=(Data_In[5] << 8);
  
  Acc.x = Raw_Acc[0] * ADXL345_DATA_RESOLUTION;
  Acc.y = Raw_Acc[1] * ADXL345_DATA_RESOLUTION;
  Acc.z = Raw_Acc[2] * ADXL345_DATA_RESOLUTION;
  
  return 1;
}

/**
* \Initiate ADXL345 by using software I2C
*/
unsigned char init_ADXL345_Software(){
  
  //init_IIC_Software();
  I2C_Init();
  
  unsigned char Data_Out[2];
  
  /* Data format: 
  * (1)full resolution, 4mg/LSB
  * (2)-16g ~ +16g
  * (3)right justified
  */
  Data_Out[0] = ADXL345_REGISTER_DATA_FORMAT;
  Data_Out[1] = 0x2B;
  //write_Buffer_Software(ADXL345_DEVICE_ADDRESS_8, Data_Out, 2);
  I2C_Write_Buffer(ADXL345_DEVICE_ADDRESS_8, Data_Out, 2);
  
  /* BW rate: 
  * (1)100Hz
  */
  Data_Out[0] = ADXL345_REGISTER_BW_RATE;
  Data_Out[1] = 0x0A;
  //write_Buffer_Software(ADXL345_DEVICE_ADDRESS_8, Data_Out, 2);
  I2C_Write_Buffer(ADXL345_DEVICE_ADDRESS_8, Data_Out, 2);
  
  /* Power control: 
  * (1)measurement mode
  * (2)link activity and inactivity function
  */
  Data_Out[0] = ADXL345_REGISTER_POWER_CTL;
  Data_Out[1] = 0x28;
  //write_Buffer_Software(ADXL345_DEVICE_ADDRESS_8, Data_Out, 2);
  I2C_Write_Buffer(ADXL345_DEVICE_ADDRESS_8, Data_Out, 2);
  
  /* INT enable: 
  * (1)disable INT
  */
  Data_Out[0] = ADXL345_REGISTER_INT_ENABLE;
  Data_Out[1] = 0x00;
  //write_Buffer_Software(ADXL345_DEVICE_ADDRESS_8, Data_Out, 2);
  I2C_Write_Buffer(ADXL345_DEVICE_ADDRESS_8, Data_Out, 2);
  
  /* INT map: 
  * (1)no seting
  */
  Data_Out[0] = ADXL345_REGISTER_INT_MAP;
  Data_Out[1] = 0x00;
  //write_Buffer_Software(ADXL345_DEVICE_ADDRESS_8, Data_Out, 2);
  I2C_Write_Buffer(ADXL345_DEVICE_ADDRESS_8, Data_Out, 2);
  
  /* OSF setting: 
  * all zero
  */
  Data_Out[0] = ADXL345_REGISTER_OSFX;
  Data_Out[1] = 0x00;
  //write_Buffer_Software(ADXL345_DEVICE_ADDRESS_8, Data_Out, 2);
  I2C_Write_Buffer(ADXL345_DEVICE_ADDRESS_8, Data_Out, 2);
  Data_Out[0] = ADXL345_REGISTER_OSFY;
  I2C_Write_Buffer(ADXL345_DEVICE_ADDRESS_8, Data_Out, 2);
  Data_Out[0] = ADXL345_REGISTER_OSFZ;
  I2C_Write_Buffer(ADXL345_DEVICE_ADDRESS_8, Data_Out, 2);
  
  return 1;
}

/**
* \Get ADXL345 device ID by useing software I2C
*/
unsigned char get_ADXL345_ID_Software() {
  unsigned char Data_Out = ADXL345_REGISTER_DEVICE_ID;
  unsigned char Data_In;
  
  read_Buffer_Software(ADXL345_DEVICE_ADDRESS_8,
                       &Data_Out,
                       1,
                       &Data_In,
                       1);
  //I2C_Write_Buffer(ADXL345_DEVICE_ADDRESS_8, &Data_Out, 1);
  //I2C_Read_Buffer(ADXL345_DEVICE_ADDRESS_8, &Data_In, 1);
  
  return Data_In;
}

/**
* \Get acceleration data by using software I2C
*/
unsigned char get_Raw_Acceleration_Software() {
  unsigned char Data_Out = ADXL345_REGISTER_DATAX0;
  unsigned char Data_In[6];
  int Raw_Acc[3];
  
  /*read_Buffer_Software(ADXL345_DEVICE_ADDRESS_7,
  &Data_Out,
  1,
  Data_In,
  6);*/
  I2C_Write_Buffer(ADXL345_DEVICE_ADDRESS_8, &Data_Out, 1);
  I2C_Read_Buffer(ADXL345_DEVICE_ADDRESS_8, Data_In, 6);
  String[0] = Data_In[0];
  String[1] = Data_In[1];
  
  String[2] = Data_In[2];
  String[3] = Data_In[3];
  
  String[4] = Data_In[4];
  String[5] = Data_In[5];
  
  String[6] = 'E';
  String[7] = 'N';
  String[8] = 'D';
  
  String[9] = '#';
  
  Raw_Acc[0] = Data_In[0];
  Raw_Acc[0] +=(Data_In[1] << 8);
  Raw_Acc[1] = Data_In[2];
  Raw_Acc[1] +=(Data_In[3] << 8);
  Raw_Acc[2] = Data_In[4];
  Raw_Acc[2] +=(Data_In[5] << 8);
  
  Acc.x = Raw_Acc[0] * ADXL345_DATA_RESOLUTION;
  Acc.y = Raw_Acc[1] * ADXL345_DATA_RESOLUTION;
  Acc.z = Raw_Acc[2] * ADXL345_DATA_RESOLUTION;
  Acc.SVM = sqrt(Acc.x * Acc.x + Acc.y * Acc.y + Acc.z * Acc.z);
  
  return 1;
}

/**
* \Algorithm to detect falling
*/
unsigned char detect_Falling() {
  switch (State) {    
  case ACTIVITY:
    if ((Acc.SVM < T_U_A_5) && \
      (Acc.SVM > T_L_A_5))
      State = INACTIVITY;
    else if (Acc.SVM < T_L_A_1){
      Flag_Free_Fall = 1;
      State = FREE_FALL;
    }
    else
      State = ACTIVITY;
    break;
    
  case INACTIVITY:
    if ((Flag_Free_Fall == 1) && (Flag_Impact == 1)){ // Period 5
      Time = Time + 1;
      // X-axis's acceleration does not equal zero
      if ((Acc.x > T_U_AX_5) || \
        (Acc.x < T_L_AX_5)){
          Flag_Free_Fall = 0;
          Flag_Impact = 0;
          State = INACTIVITY;
        }
      // Last condition of fall recognizition
      else if (Time > T_U_TIME_5){
        Time = 0;
        Flag_Fall = 1;
        Flag_Free_Fall = 0;
        Flag_Impact = 0;
        State = INACTIVITY;
      }
      else if ((Acc.SVM < T_U_A_5) && \
        (Acc.SVM > T_L_A_5))
        State = INACTIVITY;
      else { // Not inactivity
        Time = 0;
        Flag_Free_Fall = 0;
        Flag_Impact = 0;
        State = ACTIVITY;
      }
    }
    else if ((Flag_Free_Fall == 0) && (Flag_Impact == 0)){
      if ((Acc.SVM < T_U_A_5) && \
        (Acc.SVM > T_L_A_5))
        State = INACTIVITY;
      else if (Acc.SVM < T_L_A_1){
        Flag_Free_Fall = 1;
        State = FREE_FALL;
      }
      else
        State = ACTIVITY;
    }
    else{ // Error logic of flag
      Time = 0;
      Flag_Free_Fall = 0;
      Flag_Impact = 0;
      State = ACTIVITY;
    }
    break;
    
  case FREE_FALL:
    Time = Time + 1;
    // Period 1 is too long
    if (Time > T_U_TIME_1){
      Time = 0;
      Flag_Free_Fall = 0;
      State = ACTIVITY;
    }
    else if (Acc.SVM < T_L_A_1)
      State = FREE_FALL;
    else{ 
      Time = 0;
      State = TRANSITION;
    }
    break;
    
  case IMPACT:
    Time = Time + 1;
    // Period 3 is too long
    if (Time > T_U_TIME_3){
      Time = 0;
      Flag_Free_Fall = 0;
      Flag_Impact = 0;
      State = ACTIVITY;
    }
    else if (Acc.SVM > T_U_A_3)
      State = IMPACT;
    else{
      Time = 0;
      State = TRANSITION;
    }
    break;
    
  case TRANSITION:
    Time = Time + 1;
    if ((Flag_Free_Fall == 1) && (Flag_Impact == 0)){ // Period 2
      // Period 2 is too long
      if (Time > T_U_TIME_2){
        Time = 0;
        Flag_Free_Fall = 0;
        State = ACTIVITY;
      }
      else if (Acc.SVM > T_U_A_3){
        Time = 0;
        Flag_Impact = 1;
        State = IMPACT;
      }
      else
        State = TRANSITION;
    }
    else if((Flag_Free_Fall == 1) && (Flag_Impact == 1)) {  // Period 4
      // Period 4 is long enough
      if (Time > T_U_TIME_4){
        Time = 0;
        Flag_Free_Fall = 1;
        Flag_Impact = 1;
        State = INACTIVITY;
      }
      else
        State = TRANSITION;
    }
    else{ // Error logic of flag
      Time = 0;
      Flag_Free_Fall = 0;
      Flag_Impact = 0;
      State = ACTIVITY;
    }
    break;
    
  default:  // Error logic of state
    Time = 0;
    Flag_Free_Fall = 0;
    Flag_Impact = 0;
    State = ACTIVITY;
    break;
  }
  return 1;
}

/**
* \Timer A interrupt service
*/
#pragma vector = TIMERA0_VECTOR
__interrupt void TIMER_A0_ISR() {
  
  get_Raw_Acceleration_Software();
  
  sendTo_U0(String);
  
  detect_Falling();
  
  if(Flag_Fall == 1) {
    show_LED_Quickly();
    Flag_Fall = 0;
  } 
  //printf("%6.2f\t\t%6.2f\t\t%6.2f\n", Acc.x, Acc.y, Acc.z);
  
}