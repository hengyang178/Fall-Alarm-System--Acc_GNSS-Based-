#include <msp430x16x.h>
#include <stdio.h>
#include "../Header Files/error_define.h"
#include "../Header Files/eeprom.h"
#include "../Header Files/iic_software.h"
#include "../Header Files/i2c_software.h"
#include "../Header Files/i2c_hardware.h"
#include "../Header Files/i2c.h"
#include "../Header Files/usart.h"
#include "../Header Files/io.h"

#define   EEPROM_DEVICE_ADDRESS_8   0xA0  // 8-bits addressing
#define   EEPROM_DEVICE_ADDRESS_7   0x50  // 7-bits addressing
#define   EEPROM_DEVICE_ADDRESS_EX  0x0050

#define	  BUFFER_OUT_LENGTH		3
#define	  BUFFER_IN_LENGTH		3
#define	  EEPROM_MEM_LENGTH		2
#define	  DATA_LENGTH		        1

#define   TEST_NUMBER               0x36
#define	  FLAG			    1

unsigned char Buffer_Out[3] = {0x00, 0x00, TEST_NUMBER};
unsigned char Buffer_In[3] = {0xff, 0xff, 0xff};

/**
 * \Using iic_software.c
 */
unsigned char test_EEPROM_IIC_Software() {
  init_IIC_Software();
  
#if FLAG == 0
  if(write_Buffer_Software(EEPROM_DEVICE_ADDRESS_8,
               Buffer_Out,
               BUFFER_OUT_LENGTH))
    show_LED_Slowly();
  else
    show_LED_Quickly();
  
#else
  if(read_Buffer_Software(EEPROM_DEVICE_ADDRESS_8,
                 Buffer_Out,
		  EEPROM_MEM_LENGTH,
                 Buffer_In,
                 DATA_LENGTH)) {
    if(Buffer_In[0] == TEST_NUMBER)
      show_LED_Slowly();
    else
      show_LED_Quickly();
  }
  else
    printf("Can't read!\n");
  printf("Buffer_In[0] = %x\n", Buffer_In[0]);
#endif
  
  return 1;
}

/**
 * \Using i2c_software.c
 */
unsigned char test_EEPROM_I2C_Software() {
  I2C_Init();
  
#if FLAG == 0
  if(I2C_Write_Buffer(EEPROM_DEVICE_ADDRESS_8,
               Buffer_Out,
               BUFFER_OUT_LENGTH) == SUCCESS)
    show_LED_Slowly();
  else
    show_LED_Quickly();
  
#else
  if(I2C_Write_Buffer(EEPROM_DEVICE_ADDRESS_8,
                 Buffer_Out,
                 EEPROM_MEM_LENGTH) == SUCCESS) {
    if(I2C_Read_Byte(EEPROM_DEVICE_ADDRESS_8, Buffer_In) == SUCCESS) {
      if(Buffer_In[0] == TEST_NUMBER)
        show_LED_Slowly();
      else
        show_LED_Quickly();
    }
    else
      printf("Can't read byte!\n");
  }
  else
    printf("Can't write buffer!\n");
  printf("Buffer_In[0] = %x\n", Buffer_In[0]);
#endif
  
  return 1;
}

/**
 * \Using i2c_hardware.c
 */
unsigned char test_EEPROM_I2C_Hardware() {
  init_I2C_Hardware();
  
#if FLAG == 0
  if(write_Buffer_Hardware(EEPROM_DEVICE_ADDRESS_7,
                           Buffer_Out, 
                           BUFFER_OUT_LENGTH))
    show_LED_Slowly();
  else
    show_LED_Quickly();
  
#else
  if(read_Buffer_Hardware(EEPROM_DEVICE_ADDRESS_7,
                          Buffer_Out, 
                          EEPROM_MEM_LENGTH, 
                          Buffer_In, 
                          DATA_LENGTH)) {
    if(Buffer_In[0] == TEST_NUMBER)
      show_LED_Slowly();
    else
      show_LED_Quickly();
  }
  
  char String[4];
  String[0] = Buffer_In[0];
  String[1] = '\r';
  String[2] = '\n';
  String[3] = '#';
  init_U0();
  sendTo_U0(String);
  
  printf("Buffer_In[0] = %x\n", Buffer_In[0]);
  
#endif
  
  return 1;
}

/**
 * \Using i2c.c
 */
unsigned char test_EEPROM_I2C() {
  
#if FLAG == 0
  I2C_Init_Hardware(EEPROM_DEVICE_ADDRESS_EX, BUFFER_OUT_LENGTH);
  I2C_Write_Hardware(Buffer_Out, 3);
  
#else
  I2C_Init_Hardware(EEPROM_DEVICE_ADDRESS_EX, EEPROM_MEM_LENGTH);
  I2C_Write_Hardware(Buffer_Out, EEPROM_MEM_LENGTH);
  I2C_Set_Data_Length_Hardware(DATA_LENGTH);
  I2C_Read_Hardware(Buffer_In, DATA_LENGTH);
  if(Buffer_In[0] == TEST_NUMBER)
    show_LED_Slowly();
  else
    show_LED_Quickly();
  printf("Buffer_In[0] = %x\n", Buffer_In[0]);
  
#endif
  
  return 1;
}