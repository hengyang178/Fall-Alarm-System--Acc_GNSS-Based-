/**
 * Softeware I2C Driver
 *
 * @author boreal
 * @date 2011/10/28
 */
#include "../bsp/bsp.h"
#include "../bsp/bsp_software_delay.h"
#include "../Header Files/error_define.h"
#include "../Header Files/i2c_software.h"

#define I2C_DIR   P3DIR
#define I2C_OUT   P3OUT
#define I2C_IN    P3IN
#define I2C_SEL   P3SEL

#define I2C_SCL   BIT3 					// SCL Pin P3.3
#define I2C_SDA   BIT1					// SDA Pin P3.1
#define S_SDA	  I2C_OUT |= I2C_SDA	// Set SDA
#define S_SCL 	  I2C_OUT |= I2C_SCL	// Set SCL
#define C_SDA	  I2C_OUT &= ~I2C_SDA	// Reset SDA
#define C_SCL     I2C_OUT &= ~I2C_SCL	// Reset SCL
#define SDA_IN    I2C_DIR &= ~I2C_SDA   // Set SDA Direction: input
#define SDA_OUT   I2C_DIR |= I2C_SDA	// Set SDA Direction: output
#define READ_SDA  (I2C_IN&I2C_SDA)		// Read SDA Input
#define DELAY_NUM 	5

static void delay();
static void start();
static void stop();
static void ack();
static void nack();
static unsigned char write_Byte(unsigned char data);
static unsigned char read_Byte();

void I2C_Init(void) {
	I2C_SEL &= ~I2C_SDA; //Remove I2C(USART0) Pins
	I2C_SEL &= ~I2C_SCL; //Remove I2C(USART0) Pins
	I2C_DIR |= I2C_SCL; //Set SCL Direction: output
	I2C_DIR |= I2C_SDA; //Set SDA Direction: output
}

unsigned char I2C_Write_Byte(unsigned char addr, unsigned char data) {
	addr &= ~0x01; // Write address
	start();
	if (write_Byte(addr)) {
		/* write address error */
		stop();
		return EEPROM_ADDR_ERROR;
	}
	if (write_Byte(data)) {
		stop();
		return EEPROM_DATA_ERROR;
	}
	stop();
	//SW_delay_ms(10);
	// Todo
	return SUCCESS;
}

unsigned char I2C_Write_Buffer(unsigned char addr, unsigned char * buffer,
		unsigned int len) {
	addr &= ~0x01; // Write address
	start();
	if (write_Byte(addr)) {
		/* write address error */
		stop();
		return EEPROM_ADDR_ERROR;
	}
	while (len-- > 0) {
		if (write_Byte(*buffer)) {
			stop();
			return EEPROM_DATA_ERROR;
		}
		buffer++;
	}
	stop();
	//SW_delay_ms(10);
	// Todo
	return SUCCESS;
}

unsigned char I2C_Read_Byte(unsigned char addr, unsigned char* data) {
	addr |= 0x01; // Read address
	start();
	if (write_Byte(addr)) {
		/* write address error */
		stop();
		return EEPROM_ADDR_ERROR;
	}
	*data = read_Byte();

	stop();
	return SUCCESS;
}

unsigned char I2C_Read_Buffer(unsigned char addr, unsigned char * buffer,
		unsigned int len) {
	unsigned int i;
	addr |= 0x01; // Read address
	start();
	if (write_Byte(addr)) {
		/* write address error */
		stop();
		return EEPROM_ADDR_ERROR;
	}
	for (i = 0; i < len; i++) {
		buffer[i] = read_Byte();
		if (i < (len - 1))
			ack();
	}
	nack();
	stop();
	return SUCCESS;
}

/**
 * \function start
 * \brief time sequence to start I2C bus
 */
void start() {
	I2C_Init(); //Initialize I2C Bus
	SDA_OUT;

	S_SDA;
	S_SCL;
	delay();
	C_SDA;
	delay();
	delay();
	C_SCL;
}

/**
 * \function stop
 * \brief time sequence to release I2C bus
 */
void stop() {
	SDA_OUT;
	C_SDA;
	delay();
	S_SCL;
	delay();
	delay();
	S_SDA;
}

/**
 * \function ack
 * \brief acknowledge signal
 */
void ack() {
	C_SCL;
	delay();
	SDA_OUT;
	C_SDA;
	delay();
	S_SCL;
	delay();
	C_SCL;
}

/**
 * \function nack
 * \brief to indicate the slave to stop sending
 */
void nack() {
	C_SCL;
	delay();
	SDA_OUT;
	S_SDA;
	delay();
	S_SCL;
	delay();
	C_SCL;
}

/**
 * \function delay
 * \brief short time delay
 */
void delay() {
	unsigned char q0;
	for (q0 = 0; q0 < DELAY_NUM; q0++) {
		_NOP();
	}
}

/**
 * \function read_Byte
 * \brief read a byte from I2C bus according to I2C time sequence
 * \return a byte data received
 */
unsigned char read_Byte() {
	unsigned char i, q0, readData;
	SDA_IN;
	for (i = 0; i < 8; i++) {
		S_SCL;
		readData <<= 1;
		q0 = READ_SDA;
		if (q0)
			readData = readData | 0x1;
		C_SCL;
		delay();
	}
	return (readData);
}

/**
 * \function write_Byte
 * \brief write a byte to I2C bus according to I2C time sequence. MSB
 * \param[in] data: a byte to send
 * \return ack from slave device, 0 for success
 */
unsigned char write_Byte(unsigned char data) {
	unsigned char i, q0, ack;

	SDA_OUT;
	for (i = 0; i < 8; i++) // shift 8 bit
			{
		q0 = data & 0x80;
		delay();
		data = data << 1;
		if (q0)
			S_SDA;
		else
			C_SDA;
		delay();
		S_SCL;
		delay();
		C_SCL;
	}
	SDA_IN;
	//SDA = 1;
	delay();
	S_SCL;
	delay();
	delay();
	ack = READ_SDA;
	C_SCL;
	return ack; // 0 for success
}
