#include <msp430x16x.h>
#include "../Header Files/flash.h"

/**
 * \Erase whole segment and write numeric bytes
 */
unsigned char write_Byte(unsigned int Addr, 
                         unsigned char *Byte, 
                         unsigned char Num)
{
  unsigned char *ptr;
  WDTCTL = WDTPW + WDTHOLD;       // Disable watch dog
  _DINT();                        //Disable interrupt
  
  ptr = (unsigned char *) Addr;   // write data
  while (FCTL3 & BUSY);
  // Configuration
  FCTL2 = FWKEY + FSSEL_2 + FN0;  // SMCLK/2
  
  // Erase the whole segment
  FCTL1 = FWKEY + ERASE;
  FCTL3 = FWKEY;                  // clear lock
  *ptr = 0;
  FCTL1 = FWKEY + WRT;            // enable write
  
  while((Num --) != 0){
    // Write every byte
    *(ptr ++) = *(Byte ++);
    while(!(FCTL3 & WAIT));
  }
  
  // Lock
  while (FCTL3 & BUSY);
  FCTL1 = FWKEY;
  FCTL3 = FWKEY + LOCK;

  WDTCTL = WDTPW + WDTHOLD;
  _EINT();                        //Enable interrupts
  return 1;
}

/**
 * \Erase the whole segment which contains Addr, content will be 0FF at last
 */
unsigned char erase_Segment(unsigned int Addr){
  unsigned char *ptr;
  WDTCTL = WDTPW + WDTHOLD;
  _DINT();
  
  ptr = (unsigned char *)Addr;
  while (FCTL3 & BUSY);
  FCTL2 = FWKEY + FSSEL_2 + FN0;  // SMCLK/2
  
  FCTL3 = FWKEY;
  FCTL1 = FWKEY + ERASE;
  *ptr = 0;
  
  while (FCTL3 & BUSY);
  FCTL1 = FWKEY;
  FCTL3 = FWKEY + LOCK;
  
  WDTCTL = WDTPW + WDTHOLD;
  _EINT();
  return 1;
}