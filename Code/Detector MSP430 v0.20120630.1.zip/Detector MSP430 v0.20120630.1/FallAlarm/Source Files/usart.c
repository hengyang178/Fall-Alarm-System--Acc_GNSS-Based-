#include <msp430x16x.h>
#include <stdio.h>
#include "../Header Files/usart.h"

/**
 * \USART0 initiation
 */
unsigned char init_U0(){
  U0CTL = 0x00; // Clear U0CTL first when set I2C before
  U0CTL = SWRST;  // Don't use '|=' when set I2C before
  P3SEL |= 0x30;                     // Select P3.4,5 as usart
  ME1 |= URXE0 + UTXE0;                     // RX mode
  U0CTL |= CHAR;                    // Select 8-bit character
  U0TCTL |= SSEL1;                  // UCLK = SMCLK
  U0BR0 = 0x45;                     // 8M / 115200 = 69.44
  U0BR1 = 0x00;
  U0MCTL = 0x00;                    // Modulation
  U0CTL &= ~SWRST;                  // USART reset released for operation
  IE1 |= URXIE0;
  return 1;
}

/**
 * \USART1 initiation
 */
unsigned char init_U1(){
  U1CTL = 0x00;
  U1CTL = SWRST;
  P3SEL |= 0xc0;                     // Select P3.6,7 as usart
  ME2 |= UTXE1 + URXE1;             // RX and TX mode
  U1CTL |= CHAR;                    // Select 8-bit data
  U1TCTL |= SSEL1;                  // UCLK = SMCLK
  U1BR0 = 0x45;                     // 8M / 115200 = 69.44
  U1BR1 = 0x00;
  U1MCTL = 0x00;                    // Modulation 0.44
  U1CTL &= ~SWRST;                  // USART reset released for operation
  IE2 |= URXIE1;
  return 1;
}

/**
 * \Send a string to PC
 */
unsigned char sendTo_U0(char *String){
  IFG1 |= UTXIFG0;
  while(1){
    if(*String == '#')
      break;
    while(!(IFG1 & UTXIFG0));
    U0TXBUF = *String;
    String ++;
  }
  return 1;
}