#include <msp430x16x.h>
#include "../Header Files/i2c_hardware.h"

/**
 * \Initiate hardware I2C module
 */
unsigned char init_I2C_Hardware() {
  
  P3SEL |= 0x0A;  // Select I2C pins
  
  //U0CTL |= SWRST; // Set SWRST
  U0CTL |= I2C + SYNC;  // Choose I2C mode
  U0CTL &= ~CHAR; // Clear CHAR bit
  
  U0CTL &= ~I2CEN;  // Disable I2C module
  
  I2CTCTL = I2CSSEL1;  // SMCLK
  
  //I2CPSC |= 0x01; // Clock divider
  //I2CSCLH |= 0x03;  // High period of SCL
  //I2CSCLL |= 0x03;  // Low period of SCL
  
  U0CTL |= I2CEN;  // Enable I2C module
  
  return 1;
}

/**
 * \Write buffer through hardware I2C
 */
unsigned char write_Buffer_Hardware(unsigned char Slave_Addr,
                                    unsigned char *Byte_W,
                                    unsigned char NDAT_W) {
  U0CTL |= MST; // Master mode
  I2CSA = Slave_Addr;
  I2CNDAT = NDAT_W;
  
  I2CTCTL |= I2CSTT + I2CSTP + I2CTRX; // Transmit mode, auto start and stop
  
  while(I2CTCTL & I2CSTT);  // Wait start signal
  while(NDAT_W --) {
    while(!(I2CIFG & TXRDYIFG));  // Wait if cannot send now
    I2CDRB = *Byte_W;
    Byte_W ++;
  }
  
  while(I2CTCTL & I2CSTP);
  
  return 1;
}

/**
 * \Read buffer through hardware I2C
 */
unsigned char read_Buffer_Hardware(unsigned char Slave_Addr,
                                   unsigned char *Byte_W,
                                    unsigned char NDAT_W,
                                    unsigned char *Byte_R,
                                    unsigned char NDAT_R) {
  I2CSA = Slave_Addr;
  I2CNDAT = NDAT_W;
  U0CTL |= MST; // Master mode
  
  I2CTCTL |= I2CSTT + I2CTRX; // Transmit mode, send start signal
  
  while(I2CTCTL & I2CSTT);  // Wait start signal
  while(NDAT_W --) {
    while(!(I2CIFG & TXRDYIFG));
    I2CDRB = *Byte_W;
    Byte_W ++;
  }
  
  while(!(I2CIFG & ARDYIFG)); // Wait if cannot access I2C now
  I2CNDAT = NDAT_R;
  U0CTL |= MST; // Master mode
  
  I2CTCTL &= ~I2CTRX;  // Clear I2CTRX
  I2CTCTL |= I2CSTT + I2CSTP;  // Restart and stop
  
  while(I2CTCTL & I2CSTT);  // Wait start signal
  while(NDAT_R --) {
    while(!(I2CIFG & RXRDYIFG));
    *Byte_R = I2CDRB;
    Byte_R ++;
  }
  
  while(I2CTCTL & I2CSTP);  // Wait stop signal
  
  return 1;
}