#include <msp430x16x.h>
#include "../Header Files/io.h"
#include "../Header Files/delay.h"

/**
 * \I/O initiation
 * \P4.0 for power on SIM908
 * \P4.1,2 for LED
 * \P4.5 for beeper
 */
unsigned char  init_IO(){
  P4SEL &= 0xc0;                // Select P4.0,1,2,3,4,5 as general IO
  P4DIR = 0x27;                // P4.0,1,2,5 output, others input
  P4OUT |= 0x01;                // P4.0 output 1
  P4OUT &= 0xd9;                // P4.1,2,5 output 0
  return 1;
}

/**
 * \Show both LED P4.1,2 quickly
 */
unsigned char show_LED_Quickly(){
  for(unsigned char Count = 0; Count < 10; Count ++){
    P4OUT |= 0x06;
    delay_ms(150);
    P4OUT &= 0xf9;
    delay_ms(150);
  }
  return 1;
}

/**
 * \Show both LED P4.1,2 slowly
 */
unsigned char show_LED_Slowly(){
  for(unsigned char Count = 0; Count < 5; Count ++){
    P4OUT |= 0x06;
    delay_s(1);
    P4OUT &= 0xf9;
    delay_s(1);
  }
  return 1;
}

/**
 * \Open active beeper
 */
unsigned char open_Active_Beeper(){
  unsigned char temp;
  for(temp = 0; temp < 3; temp++) {
    P4OUT |= 0x20;
    delay_ms(100);
    P4OUT &= 0xdf;
    delay_ms(100);
  }
  return 1;
}

/**
 * \Open inactive beeper
 */
unsigned char open_Inactive_Beeper(){
  unsigned char count1, count2;
  
  for(count1 = 0; count1 < 3; count1 ++) {
    for(count2 = 0; count2 < 255; count2 ++) {
      P4OUT |= 0x20;
      delay_us(500);
      P4OUT &= 0xdf;
      delay_us(500);
    }
    delay_s(1);
  }
  
  return 1;
}

/**
 * \Scan S3 button, return 1 when S3 button is pressed
 */
unsigned char scan_Button_S3() {
  if(!(P4IN & 0x08)) {
    delay_ms(10);
    if(!(P4IN & 0x08))
      return 1;
  }
  return 0;
}

/**
 * \Scan S4 button, return 1 when S3 button is pressed
 */
unsigned char scan_Button_S4() {
  if(!(P4IN & 0x10)) {
    delay_ms(10);
    if(!(P4IN & 0x10))
      return 1;
  }
  return 0;
}