
function [acc_aver1, acc_aver2, acc_aver3] = filter_average(data_min_len, acc_raw)

% Macro definition
SAMPLING_RATE = 100; % 100Hz
TIME_INTERVAL = 0.01; % 0.01s

%% Weighting average filter 1
averageLen = 10; % Average time set to 300ms
power = 1;

acc_aver1 = acc_raw;
for count = 1 : data_min_len
    sumX = (power - 1) * acc_raw(1, count);
    sumY = (power - 1) * acc_raw(2, count);
    sumZ = (power - 1) * acc_raw(3, count);
    for countAver = (-averageLen / 2) : 1 : (averageLen / 2)
        if (count + countAver) < 1  % Signal head
            sumX = sumX + acc_raw(1, 1);
            sumY = sumY + acc_raw(2, 1);
            sumZ = sumZ + acc_raw(3, 1);
        elseif (count + countAver) > data_min_len % Signal tail
            sumX = sumX + acc_raw(1, data_min_len);
            sumY = sumY + acc_raw(2, data_min_len);
            sumZ = sumZ + acc_raw(3, data_min_len);
        else
            sumX = sumX + acc_raw(1, count + countAver);
            sumY = sumY + acc_raw(2, count + countAver);
            sumZ = sumZ + acc_raw(3, count + countAver);
        end
    end
    acc_aver1(1, count) = sumX / (averageLen + 1 + power - 1);
    acc_aver1(2, count) = sumY / (averageLen + 1 + power - 1);
    acc_aver1(3, count) = sumZ / (averageLen + 1 + power - 1);
end
for count = 1 : data_min_len
    acc_aver1(4, count) = ...
        sqrt(acc_aver1(1, count)^2 + acc_aver1(2, count)^2 + acc_aver1(3, count)^2);
end

%% Weighting average filter 2
averageLen = 50; % Average time set to 300ms
power = 1;

acc_aver2 = acc_aver1;
for count = 1 : data_min_len
    sumX = (power - 1) * acc_aver1(1, count);
    sumY = (power - 1) * acc_aver1(2, count);
    sumZ = (power - 1) * acc_aver1(3, count);
    for countAver = (-averageLen / 2) : 1 : (averageLen / 2)
        if (count + countAver) < 1
            sumX = sumX + acc_aver1(1, 1);
            sumY = sumY + acc_aver1(2, 1);
            sumZ = sumZ + acc_aver1(3, 1);
        elseif (count + countAver) > data_min_len
            sumX = sumX + acc_aver1(1, data_min_len);
            sumY = sumY + acc_aver1(2, data_min_len);
            sumZ = sumZ + acc_aver1(3, data_min_len);
        else
            sumX = sumX + acc_aver1(1, count + countAver);
            sumY = sumY + acc_aver1(2, count + countAver);
            sumZ = sumZ + acc_aver1(3, count + countAver);
        end
    end
    acc_aver2(1, count) = sumX / (averageLen + 1 + power - 1);
    acc_aver2(2, count) = sumY / (averageLen + 1 + power - 1);
    acc_aver2(3, count) = sumZ / (averageLen + 1 + power - 1);
end
for count = 1 : data_min_len
    acc_aver2(4, count) = ...
        sqrt(acc_aver2(1, count)^2 + acc_aver2(2, count)^2 + acc_aver2(3, count)^2);
end

%% Weighting average filter 3
averageLen = 100; % Average time set to 300ms
power = 1;

acc_aver3 = acc_aver2;
for count = 1 : data_min_len
    sumX = (power - 1) * acc_aver2(1, count);
    sumY = (power - 1) * acc_aver2(2, count);
    sumZ = (power - 1) * acc_aver2(3, count);
    for countAver = (-averageLen / 2) : 1 : (averageLen / 2)
        if (count + countAver) < 1
            sumX = sumX + acc_aver2(1, 1);
            sumY = sumY + acc_aver2(2, 1);
            sumZ = sumZ + acc_aver2(3, 1);
        elseif (count + countAver) > data_min_len
            sumX = sumX + acc_aver2(1, data_min_len);
            sumY = sumY + acc_aver2(2, data_min_len);
            sumZ = sumZ + acc_aver2(3, data_min_len);
        else
            sumX = sumX + acc_aver2(1, count + countAver);
            sumY = sumY + acc_aver2(2, count + countAver);
            sumZ = sumZ + acc_aver2(3, count + countAver);
        end
    end
    acc_aver3(1, count) = sumX / (averageLen + 1 + power - 1);
    acc_aver3(2, count) = sumY / (averageLen + 1 + power - 1);
    acc_aver3(3, count) = sumZ / (averageLen + 1 + power - 1);
end
for count = 1 : data_min_len
    acc_aver3(4, count) = ...
        sqrt(acc_aver3(1, count)^2 + acc_aver3(2, count)^2 + acc_aver3(3, count)^2);
end

%% Compare raw data and averaged data
figure('name', 'Data raw and after average');
subplot(4,1,1),
plot(acc_raw(1, :), 'Color', 'r'), hold on;
plot(acc_raw(2, :), 'Color', 'g'), hold on;
plot(acc_raw(3, :), 'Color', 'b'), hold on;
plot(acc_raw(4, :), 'Color', 'k');
title('Data raw');
grid on;
subplot(4,1,2),
plot(acc_aver1(1, :), 'Color', 'r'), hold on;
plot(acc_aver1(2, :), 'Color', 'g'), hold on;
plot(acc_aver1(3, :), 'Color', 'b'), hold on;
plot(acc_aver1(4, :), 'Color', 'k');
title('Data after 1st step average');
grid on;
subplot(4,1,3),
plot(acc_aver2(1, :), 'Color', 'r'), hold on;
plot(acc_aver2(2, :), 'Color', 'g'), hold on;
plot(acc_aver2(3, :), 'Color', 'b'), hold on;
plot(acc_aver2(4, :), 'Color', 'k');
title('Data after 2nd step average');
grid on;
subplot(4,1,4),
plot(acc_aver3(1, :), 'Color', 'r'), hold on;
plot(acc_aver3(2, :), 'Color', 'g'), hold on;
plot(acc_aver3(3, :), 'Color', 'b'), hold on;
plot(acc_aver3(4, :), 'Color', 'k');
title('Data after 3rd step average');
grid on;

end % function


