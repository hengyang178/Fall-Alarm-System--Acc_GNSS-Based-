% iir_type = 0: Butterworth
% iir_type = 1: Chebyshev
% iir_type = 2: Both Butterworth and Chebyshev

function [acc_butter, acc_cheby1] = filter_iir(data_min_len, acc_raw, iir_type)

% Macro definition
SAMPLING_RATE = 100; % 100Hz
TIME_INTERVAL = 0.01; % 0.01s

acc_butter = zeros(4, 1);
acc_cheby1 = zeros(4, 1);

%% Butterworth IIR filter
if (iir_type == 0) || (iir_type == 2)

    butter_sampleFreq = SAMPLING_RATE;
    butter_bandWidth = butter_sampleFreq / 2;
    wc = 20 / butter_bandWidth;

    butter_order = 2;

    [b, a] = butter(butter_order, wc);

    acc_butter = acc_raw;
    for i = (butter_order + 1) : data_min_len
        acc_butter(1 : 4, i) = [0; 0; 0; 0];

        for j = 0 : butter_order
            acc_butter(1, i) = acc_butter(1, i) + b(j + 1) * acc_raw(1, i - j);
            acc_butter(2, i) = acc_butter(2, i) + b(j + 1) * acc_raw(2, i - j);
            acc_butter(3, i) = acc_butter(3, i) + b(j + 1) * acc_raw(3, i - j);
        end

        for j = 1 : butter_order
            acc_butter(1, i) = acc_butter(1, i) - a(j + 1) * acc_butter(1, i - j);
            acc_butter(2, i) = acc_butter(2, i) - a(j + 1) * acc_butter(2, i - j);
            acc_butter(3, i) = acc_butter(3, i) - a(j + 1) * acc_butter(3, i - j);
        end

        acc_butter(4, i) = ...
            sqrt(acc_butter(1, i)^2 + acc_butter(2, i)^2 + acc_butter(3, i)^2);
    end

end % if

%% Chebyshev type 1 IIR filter
if (iir_type == 1) || (iir_type == 2)

    cheby1_sampleFreq = SAMPLING_RATE;
    cheby1_bandWidth = cheby1_sampleFreq / 2;
    wc = 20 / cheby1_bandWidth; 

    cheby1_order = 2;

    [b, a] = cheby1(cheby1_order, 1, wc);

    acc_cheby1 = acc_raw;
    for i = (cheby1_order + 1) : data_min_len
        acc_cheby1(1 : 4, i) = [0; 0; 0; 0];

        for j = 0 : cheby1_order
            acc_cheby1(1, i) = acc_cheby1(1, i) + b(j + 1) * acc_raw(1, i - j);
            acc_cheby1(2, i) = acc_cheby1(2, i) + b(j + 1) * acc_raw(2, i - j);
            acc_cheby1(3, i) = acc_cheby1(3, i) + b(j + 1) * acc_raw(3, i - j);
        end

        for j = 1 : cheby1_order
            acc_cheby1(1, i) = acc_cheby1(1, i) - a(j + 1) * acc_cheby1(1, i - j);
            acc_cheby1(2, i) = acc_cheby1(2, i) - a(j + 1) * acc_cheby1(2, i - j);
            acc_cheby1(3, i) = acc_cheby1(3, i) - a(j + 1) * acc_cheby1(3, i - j);
        end

        acc_cheby1(4, i) = ...
            sqrt(acc_cheby1(1, i)^2 + acc_cheby1(2, i)^2 + acc_cheby1(3, i)^2);
    end

end % if

%% Compare raw data and averaged data
t = 0 : TIME_INTERVAL : ((data_min_len - 1) * TIME_INTERVAL);

if (iir_type == 2)

    figure('name', 'Data raw and after IIR');
    subplot(3,1,1),
    plot(t, acc_raw(1, :), 'Color', 'r'), hold on;
    plot(t, acc_raw(2, :), 'Color', 'g'), hold on;
    plot(t, acc_raw(3, :), 'Color', 'b'), hold on;
    plot(t, acc_raw(4, :), 'Color', 'k');
    legend('X', 'Y', 'Z', 'Sum');
    title('Data raw');
    grid on;
    subplot(3,1,2),
    plot(t, acc_butter(1, :), 'Color', 'r'), hold on,
    plot(t, acc_butter(2, :), 'Color', 'g'), hold on,
    plot(t, acc_butter(3, :), 'Color', 'b'), hold on,
    plot(t, acc_butter(4, :), 'Color', 'k');
    legend('X', 'Y', 'Z', 'Sum');
    title('Data after Butterworth IIR');
    grid on;
    subplot(3,1,3),
    plot(t, acc_cheby1(1, :), 'Color', 'r'), hold on,
    plot(t, acc_cheby1(2, :), 'Color', 'g'), hold on,
    plot(t, acc_cheby1(3, :), 'Color', 'b'), hold on,
    plot(t, acc_cheby1(4, :), 'Color', 'k');
    legend('X', 'Y', 'Z', 'Sum');
    title('Data after Chebyshev type 1 IIR');
    grid on;

end % if

if (iir_type == 0)
    figure('name', 'Data after Butterworth IIR');
    plot(t, acc_butter(1, :), 'Color', 'r'), hold on;
    plot(t, acc_butter(2, :), 'Color', 'g'), hold on;
    plot(t, acc_butter(3, :), 'Color', 'b'), hold on;
    plot(t, acc_butter(4, :), 'Color', 'k');
    xlabel('Time/s'), ylabel('Acceleration/g');
    legend('X', 'Y', 'Z', 'Sum');
    grid on;
end

if (iir_type == 1)
    figure('name', 'Data after Chebyshev type 1 IIR');
    plot(t, acc_cheby1(1, :), 'Color', 'r'), hold on;
    plot(t, acc_cheby1(2, :), 'Color', 'g'), hold on;
    plot(t, acc_cheby1(3, :), 'Color', 'b'), hold on;
    plot(t, acc_cheby1(4, :), 'Color', 'k');
    xlabel('Time/s'), ylabel('Acceleration/g');
    legend('X', 'Y', 'Z', 'Sum');
    grid on;
end

end % function


