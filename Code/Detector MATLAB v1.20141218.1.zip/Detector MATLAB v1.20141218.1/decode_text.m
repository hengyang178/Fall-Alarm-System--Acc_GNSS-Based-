
function [acc_raw, data_min_len] = decode_text(file_name)

% Macro definition
SAMPLING_RATE = 100; % 100Hz
TIME_INTERVAL = 0.01; % 0.01s

% Record hex ASCII data_in_len, Seperate with space(ASCII=32)
data_in = textread(file_name, '%s');

%% Record data
data1 = [1,100];
data2 = [1,100];
data3 = [1,100];
data4 = [1,100];
data5 = [1,100];
data6 = [1,100];
count1 = 0;
count2 = 0;
count3 = 0;
count4 = 0;
count5 = 0;
count6 = 0;
flag_end = 0;
data_in_len = size(data_in);
for count = 1 : data_in_len(1, 1)
    data_hex = data_in(count, 1);
    data = hex2dec(data_hex);
    switch flag_end
        case 0
            if data == 'E'
                flag_end = 1;
            end
        case 1
            if data == 'N'
                flag_end = 2;
            else
                flag_end = 0;
            end
        case 2
            if data == 'D'
                flag_end = 3;
            else
                flag_end = 0;
            end
        case 3
            count1 = count1 + 1;
            data1(count1) = data;
            flag_end = 4;
        case 4
            count2 = count2 + 1;
            data2(count2) = data;
            flag_end = 5;
        case 5
            count3 = count3 + 1;
            data3(count3) = data;
            flag_end = 6;
        case 6
            count4 = count4 + 1;
            data4(count4) = data;
            flag_end = 7;
        case 7
            count5 = count5 + 1;
            data5(count5) = data;
            flag_end = 8;
        case 8
            count6 = count6 + 1;
            data6(count6) = data;
            flag_end = 0;
    end
end

%% Transform data
if count1 < count2
    data_min_len = count1;
else
    data_min_len = count2;
end

if count3 < data_min_len
    data_min_len = count3;
end

if count4 < data_min_len
    data_min_len = count4;
end

if count5 < data_min_len
    data_min_len = count5;
end

if count6 < data_min_len
    data_min_len = count6;
end

% Row 1 to 4 records x, y, z and sum acceleration separately
acc_raw = [4, data_min_len];
for count = 1 : data_min_len
    acc_raw(1, count) = data2(count) * 256 + data1(count);
    if acc_raw(1, count) >= 32768
        acc_raw(1, count) = acc_raw(1, count) - 65536;
    end
    acc_raw(1, count) = acc_raw(1, count) * 0.004; % 13 bits, -16g to +16g
end
for count = 1 : data_min_len
    acc_raw(2, count) = data4(count) * 256 + data3(count);
    if acc_raw(2, count) >= 32768
        acc_raw(2, count) = acc_raw(2, count) - 65536;
    end
    acc_raw(2, count) = acc_raw(2, count) * 0.004;
end
for count = 1 : data_min_len
    acc_raw(3, count) = data6(count) * 256 + data5(count);
    if acc_raw(3, count) >= 32768
        acc_raw(3, count) = acc_raw(3, count) - 65536;
    end
    acc_raw(3, count) = acc_raw(3, count) * 0.004;
end
for count = 1 : data_min_len
    acc_raw(4, count) = ...
        sqrt(acc_raw(1, count)^2 + acc_raw(2, count)^2 + acc_raw(3, count)^2);
end

%% Draw raw data
t = 0 : TIME_INTERVAL : ((data_min_len - 1) * TIME_INTERVAL);

figure('name', 'Raw Data');
subplot(4,1,1), plot(acc_raw(1, :)), title('X-axis Acceleration'),
xlabel('Time (10ms)'), ylabel('Value (g)');
subplot(4,1,2), plot(acc_raw(2, :)), title('Y-axis Acceleration'),
xlabel('Time (10ms)'), ylabel('Value (g)');
subplot(4,1,3), plot(acc_raw(3, :)), title('Z-axis Acceleration'),
xlabel('Time (10ms)'), ylabel('Value (g)');
subplot(4,1,4), plot(acc_raw(4, :)), title('Sum Vector Magnitude'),
xlabel('Time (10ms)'), ylabel('Magnitude (g)');

figure('name', 'Raw Data (Mixed)');
plot(t, acc_raw(1, :), 'Color', 'k', 'LineStyle', 'none', 'Marker', '+'), hold on;
plot(t, acc_raw(2, :), 'Color', 'k', 'LineStyle', 'none', 'Marker', 'o'), hold on;
plot(t, acc_raw(3, :), 'Color', 'k', 'LineStyle', 'none', 'Marker', '*'), hold on;
plot(t, acc_raw(4, :), 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2);
xlabel('Time (s)'), ylabel('Acceleration (g)');
legend('X', 'Y', 'Z', 'Sum');
grid on;

end % function