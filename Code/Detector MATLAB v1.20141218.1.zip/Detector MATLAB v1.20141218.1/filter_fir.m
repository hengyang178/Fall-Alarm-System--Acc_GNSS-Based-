
function [acc_window] = filter_fir(data_min_len, acc_raw)

% Macro definition
SAMPLING_RATE = 100; % 100Hz
TIME_INTERVAL = 0.01; % 0.01s

%% Window FIR filter
window_sampleFreq = 100;
window__bandWidth = window_sampleFreq / 2;
Wn = 20 / window__bandWidth; 

window_order = 2;

b = fir1(window_order, Wn, 'ftype', window);

acc_window = acc_raw;
for count = (window_order + 1) : data_min_len
    acc_window(1, count) = b(1) * acc_raw(1, count) + b(2) * acc_raw(1, count - 1) + b(3) * acc_raw(1, count - 2);
    acc_window(2, count) = b(1) * acc_raw(2, count) + b(2) * acc_raw(2, count - 1) + b(3) * acc_raw(2, count - 2);
    acc_window(3, count) = b(1) * acc_raw(3, count) + b(2) * acc_raw(3, count - 1) + b(3) * acc_raw(3, count - 2);
end
for count = 1 : data_min_len
    acc_window(4, count) = ...
        sqrt(acc_window(1, count)^2 + acc_window(2, count)^2 + acc_window(3, count)^2);
end


%% Compare raw data and averaged data
t = 0 : TIME_INTERVAL : ((data_min_len - 1) * TIME_INTERVAL);

figure('name', 'Data raw and after FIR');
subplot(3,1,1),
plot(t, acc_raw(1, :), 'Color', 'r'), hold on;
plot(t, acc_raw(2, :), 'Color', 'g'), hold on;
plot(t, acc_raw(3, :), 'Color', 'b'), hold on;
plot(t, acc_raw(4, :), 'Color', 'k');
legend('X', 'Y', 'Z', 'Sum');
title('Data raw');
grid on;
subplot(3,1,2),
plot(t, acc_raw(1, :), 'Color', 'r'), hold on,
plot(t, acc_raw(2, :), 'Color', 'g'), hold on,
plot(t, acc_raw(3, :), 'Color', 'b'), hold on,
plot(t, acc_raw(4, :), 'Color', 'k');
legend('X', 'Y', 'Z', 'Sum');
title('Data after FIR');
grid on;
subplot(3,1,3),
plot(t, acc_window(1, :), 'Color', 'r'), hold on,
plot(t, acc_window(2, :), 'Color', 'g'), hold on,
plot(t, acc_window(3, :), 'Color', 'b'), hold on,
plot(t, acc_window(4, :), 'Color', 'k');
legend('X', 'Y', 'Z', 'Sum');
title('Data after window FIR');
grid on;

end % function


