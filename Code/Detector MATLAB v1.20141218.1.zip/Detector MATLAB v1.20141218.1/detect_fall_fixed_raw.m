close all;
clear all;

% Macro definition
SAMPLING_RATE = 100; % 100Hz
TIME_INTERVAL = 0.01; % 0.01s

%% Decode text file to get raw acceleration data
% Record hex ASCII data_in_len, Seperate with space(ASCII=32)
%file_name = 'Data\Test Data\TestData2.txt';

%file_name = 'Data\Fall Data\FF\FF3.txt';
file_name = 'Data\Fall Data\BF\BF2.txt';
%file_name = 'Data\Fall Data\LF\LF7.txt';
%file_name = 'Data\Fall Data\RF\RF9.txt';

%file_name = 'Data\ADL Data\Jump\Jump2.txt';
%file_name = 'Data\ADL Data\Lie\Lie3.txt';
%file_name = 'Data\ADL Data\Sit\Sit2.txt';
%file_name = 'Data\ADL Data\Squat\Squat2.txt';
%file_name = 'Data\ADL Data\Walk\Walk2.txt';

[acc_raw, data_min_len] = decode_text(file_name);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Pre-declaration of algorithm threshold
% State
START = 0;
ACTIVITY = 1;
INACTIVITY = 2;
FREE_FALL = 3;
IMPACT = 4;
TRANSITION = 5;
State = START;

% Acceleration threshold
GRAVITY = 1.0;
GRAVITY_SUM_UP = 3.0;
GRAVITY_SUM_DOWN = 0.3;
GRAVITY_ZERO_UP = +0.6;
GRAVITY_ZERO_DOWN = -0.6;
THRESHOLD_FREE_FALL = 0.6;
THRESHOLD_IMPACT = 2.5;

% Time threshold
TIME_THRESHOLD_FREE_FALL = 100;
TIME_THRESHOLD_IMPACT = 100;
TIME_THRESHOLD_TRANSITION_1 = 100;
TIME_THRESHOLD_TRANSITION_2 = 200;
TIME_THRESHOLD_INACTIVITY = 150;
Time = 0; 

% Flag used to assist algorithm
Flag_Free_Fall = 0;
Flag_Impact = 0;
Flag_Fall = 0;
Fall_Number = 0;
Fall_Point = [1, 3];

%% Fall detection algorithm with fixed coordinate
% (1)The x-y-z coordinate equals to down-fore-right of human body;
% (2)The behavior of sum-acceleration in a real fall is: 
%                           free fall -> transition -> impact -> transition
%                           -> inactivity
% (3)The behavior of x acceleration in a real fall is: 
%                           -1g -> 0g
for count = 1 : data_min_len
switch (State)
  case START
    if (acc_raw(4, count) < GRAVITY_SUM_UP) && ...
            (acc_raw(4, count) > GRAVITY_SUM_DOWN)
      State = INACTIVITY;
    elseif acc_raw(4, count) < THRESHOLD_FREE_FALL
      Flag_Free_Fall = 1;
      State = FREE_FALL;
    else
      State = ACTIVITY;
    end
    
  case ACTIVITY
    if (acc_raw(4, count) < GRAVITY_SUM_UP) && ...
            (acc_raw(4, count) > GRAVITY_SUM_DOWN)
      State = INACTIVITY;
    elseif acc_raw(4, count) < THRESHOLD_FREE_FALL
      Flag_Free_Fall = 1;
      State = FREE_FALL;
    else
      State = ACTIVITY;
    end
    
  case INACTIVITY
    % Inactivity may occured in falling
    if (Flag_Free_Fall == 1) && (Flag_Impact == 1)
      Time = Time + 1;
      % X-axis's acceleration does not equal zero
      if (acc_raw(1, count) > GRAVITY_ZERO_UP) || ...
              (acc_raw(1, count) < GRAVITY_ZERO_DOWN)
        Flag_Free_Fall = 0;
        Flag_Impact = 0;
        State = START;
      % Last step of fall judge
      elseif Time > TIME_THRESHOLD_INACTIVITY
        Time = 0;
        Flag_Fall = 1;
        Flag_Free_Fall = 0;
        Flag_Impact = 0;
        State = START;
      elseif (acc_raw(4, count) < GRAVITY_SUM_UP) && ...
              (acc_raw(4, count) > GRAVITY_SUM_DOWN)
        State = INACTIVITY;
      else % Not inactivity
        Time = 0;
        Flag_Free_Fall = 0;
        Flag_Impact = 0;
        State = START;
      end
    % Normal inactivity
    elseif (Flag_Free_Fall == 0) && (Flag_Impact == 0)
      if (acc_raw(4, count) < GRAVITY_SUM_UP) && ...
              (acc_raw(4, count) > GRAVITY_SUM_DOWN)
        State = INACTIVITY;
      elseif acc_raw(4, count) < THRESHOLD_FREE_FALL
        Flag_Free_Fall = 1;
        State = FREE_FALL;
      else
        State = ACTIVITY;
      end
    else
      Time = 0;
      Flag_Free_Fall = 0;
      Flag_Impact = 0;
      State = ACTIVITY;
    end
      
    
  case FREE_FALL
    Time = Time + 1;
    % Time is too long
    if Time > TIME_THRESHOLD_FREE_FALL
      Time = 0;
      Flag_Free_Fall = 0;
      State = START;
    elseif acc_raw(4, count) < THRESHOLD_FREE_FALL
      State = FREE_FALL;
    elseif acc_raw(4, count) > THRESHOLD_IMPACT
      Time = 0;
      Flag_Impact = 1;
      State = IMPACT;
    else 
      Time = 0;
      State = TRANSITION;
    end
    
  case IMPACT
    Time = Time + 1;
    % Time is too long
    if Time > TIME_THRESHOLD_IMPACT
      Time = 0;
      Flag_Free_Fall = 0;
      Flag_Impact = 0;
      State = START;
    elseif acc_raw(4, count) > THRESHOLD_IMPACT
      State = IMPACT;
    else
      Time = 0;
      State = TRANSITION;
    end
    
  case TRANSITION
    Time = Time + 1;
    % Transition between free fall and impact
    if (Flag_Free_Fall == 1) && (Flag_Impact == 0)
      if Time > TIME_THRESHOLD_TRANSITION_1
        Time = 0;
        Flag_Free_Fall = 0;
        State = START;
      elseif acc_raw(4, count) > THRESHOLD_IMPACT
        Time = 0;
        Flag_Impact = 1;
        State = IMPACT;
      else
        State = TRANSITION;
      end
    % Transition between impact and inactivity on ground
    elseif (Flag_Free_Fall == 1) && (Flag_Impact == 1) 
      if Time > TIME_THRESHOLD_TRANSITION_2
        Time = 0;
        Flag_Free_Fall = 1;
        Flag_Impact = 1;
        State = INACTIVITY;
      else
        State = TRANSITION;
      end
    else % Error
      State = START;
    end
end % switch

% Count the number of falls
if Flag_Fall == 1
    Fall_Number = Fall_Number + 1;
    Flag_Fall = 0;
    Fall_Point(Fall_Number) = count;
end

end % for

disp(['Fall Number = ', num2str(Fall_Number)]);