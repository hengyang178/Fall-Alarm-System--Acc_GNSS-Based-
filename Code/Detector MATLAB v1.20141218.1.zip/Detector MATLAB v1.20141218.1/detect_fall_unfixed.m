close all;
clear all;

% Macro definition
SAMPLING_RATE = 100; % 100Hz
TIME_INTERVAL = 0.01; % 0.01s

%% Decode text file to get raw acceleration data
% Record hex ASCII data_in_len, Seperate with space(ASCII=32)
%file_name = 'Data\Test Data\TestData2.txt';

file_name = 'Data\Fall Data\FF\FF4.txt';
%file_name = 'Data\Fall Data\BF\BF5.txt';
%file_name = 'Data\Fall Data\LF\LF9.txt';
%file_name = 'Data\Fall Data\RF\RF1.txt';

%file_name = 'Data\ADL Data\Walk\Walk2.txt';
%file_name = 'Data\ADL Data\Jump\Jump2.txt';
%file_name = 'Data\ADL Data\Squat\Squat3.txt';
%file_name = 'Data\ADL Data\Sit\Sit1.txt';
%file_name = 'Data\ADL Data\Lie\Lie4.txt';


[acc_raw, data_min_len] = decode_text(file_name);

%% Filter

%[acc_aver1, acc_aver2, acc_aver3] = filter_average(data_min_len, acc_raw);
%[acc_butter, acc_cheby1] = filter_iir(data_min_len, acc_raw, 0);
%[acc_window] = filter_fir(data_min_len, acc_raw);

acc = acc_raw;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Pre-declaration of algorithm threshold and variables

% Acceleration definition
GRAVITY = 1.0;
ACC_UP = 0.3;
ACC_DOWN = -0.3;
THRESHOLD_IMPACT = 2.5;

% Rotation definition
ROTATION_POS = 90; % degrees
ROTATION_NEG = -90;
ROTATION_UP = 30;
ROTATION_DOWN = -30;

% Acceleration vector(Gravity vector) before and after impact
vector_before = [3, 1];
vector_after = [3, 1];

% Flag to assist the algorithm
flag_before = 0;
flag_before_head = 0;
flag_before_rear = 0;
flag_after_head = 0;
flag_after_rear = 0;
flag_impact = 0;
flag_impact_end = 0;
flag_quaternion = 0;

% Time threshold and variable to assist the algorithm
TIME_STEADY_DURATION = 50;
TIME_IMPACT_DURATION = 200; % 2.0s
time = 0;

% Variable to record fall data_in_len
fall_number = 0;
fall_record = [1, 10];

%% Fall detection algorithm with unfixed coordinate
% (1)The algorithm is based on impact detect and posture change;
% (2)The behavior of sum-acceleration in a real fall is: 
%                           posture before fall -> impact -> posture after
%                           fall
% (3)The calculate of posture change is based on the change of gravity
%    direction in accelerometer coordinate, quaternion method is used;
for count = 1 : data_min_len
    
    % Record vector before impact
    if (acc(4, count) <= GRAVITY + ACC_UP) &&...
            (acc(4, count) >= GRAVITY + ACC_DOWN) &&...
            (flag_before_head == 0) &&...
            (flag_before_rear == 0) &&...
            (flag_impact == 0)
        flag_before_head = 1;
    end
    if flag_before_head == 1
        if (acc(4, count) <= GRAVITY + ACC_UP) &&...
            (acc(4, count) >= GRAVITY + ACC_DOWN)
            time = time + 1;
            if time > TIME_STEADY_DURATION;
                time = 0;
                flag_before_rear = 1;
            end
        else
            time = 0;
            flag_before_head = 0;
        end
        if flag_before_rear == 1
            vector_before = acc(1 : 3, count);
            flag_before = 1;
            flag_before_head = 0;
            flag_before_rear = 0;
            vector_before(4) = count;
        end
    end
    
    % Impact duration
    if (acc(4, count) > THRESHOLD_IMPACT) && (flag_before == 1)
        flag_impact = 1;
    end
    if (flag_impact == 1)
        if time <= TIME_IMPACT_DURATION
            time = time + 1;
        elseif acc(4, count) > THRESHOLD_IMPACT
            flag_impact = 0;
            time = 0;
            flag_before = 0;
            disp('Time threshold too short!');
        else
            flag_impact = 0;
            time = 0;
            flag_impact_end = 1;
        end
    end
    
    % Record vector after impact
    if (acc(4, count) <= GRAVITY + ACC_UP) &&...
            (acc(4, count) >= GRAVITY + ACC_DOWN) &&...
            (flag_before == 1) &&...
            (flag_after_head == 0) &&...
            (flag_after_rear == 0) &&...
            (flag_impact_end == 1)
        flag_after_head = 1;
    end
    if flag_after_head == 1
        if (acc(4, count) <= GRAVITY + ACC_UP) &&...
            (acc(4, count) >= GRAVITY + ACC_DOWN)
            time = time + 1;
            if time > TIME_STEADY_DURATION;
                time = 0;
                flag_after_rear = 1;
            end
        else
            time = 0;
            flag_after_head = 0;
        end
        if flag_after_rear == 1
            vector_after = acc(1 : 3, count);
            flag_after_head = 0;
            flag_after_rear = 0;
            flag_impact_end = 0;
            flag_quaternion = 1; % Start to calculate the quaternion
            vector_after(4) = count;
        end
    end
    
    % Calculate the change of gravity direction by quaternion
    if flag_quaternion == 1
        % Normalization of acceleration vector
        temp = sqrt(vector_before(1) ^ 2 + vector_before(2) ^ 2 + vector_before(3) ^ 2);
        vector_before(1) = vector_before(1) / temp;
        vector_before(2) = vector_before(2) / temp;
        vector_before(3) = vector_before(3) / temp;
        temp = sqrt(vector_after(1) ^ 2 + vector_after(2) ^ 2 + vector_after(3) ^ 2);
        vector_after(1) = vector_after(1) / temp;
        vector_after(2) = vector_after(2) / temp;
        vector_after(3) = vector_after(3) / temp;
        
        % Three steps of quaternion rotation from vector before fall to
        % after fall
        seita1 = atan(vector_before(3) / sqrt(vector_before(1) ^ 2 + vector_before(2) ^ 2));
        q10 = cos(seita1 / 2);
        q11 = sin(seita1 / 2) * (-vector_before(2) / sqrt(vector_before(1) ^ 2 + vector_before(2) ^ 2));
        q12 = sin(seita1 / 2) * (vector_before(1) / sqrt(vector_before(1) ^ 2 + vector_before(2) ^ 2));
        q13 = 0;
        
        seita2 = atan2(vector_after(2), vector_after(1)) - atan2(vector_before(2), vector_before(1));
        q20 = cos(seita2 / 2);
        q21 = 0;
        q22 = 0;
        q23 = sin(seita2 / 2);
        
        seita3 = -atan(vector_after(3) / sqrt(vector_after(1) ^ 2 + vector_after(2) ^ 2));
        q30 = cos(seita3 / 2);
        q31 = sin(seita3 / 2) * (-vector_after(2) / sqrt(vector_after(1) ^ 2 + vector_after(2) ^ 2));
        q32 = sin(seita3 / 2) * (vector_after(1) / sqrt(vector_after(1) ^ 2 + vector_after(2) ^ 2));
        q33 = 0;
        
        %{
        Q1 = [q10, -q11, -q12, -q13; 
            q11, q10, -q13, q12;
            q12, q13, q10, -q11;
            q13, -q12, q11, q10];
        %}
        
        Q2 = [q20, -q21, -q22, -q23; 
            q21, q20, -q23, q22;
            q22, q23, q20, -q21;
            q23, -q22, q21, q20];
        Q3 = [q30, -q31, -q32, -q33; 
            q31, q30, -q33, q32;
            q32, q33, q30, -q31;
            q33, -q32, q31, q30];
        
        % One step quaternion from vector before fall to vector after fall
        Q = Q3 * Q2 * [q10; q11; q12; q13];
        q0 = Q(1, 1);
        q1 = Q(2, 1);
        q2 = Q(3, 1);
        q3 = Q(4, 1);
        
        % Calculate one step rotation angle, -90 to 90 degrees
        seita = 2 * atan(sqrt(q1 ^ 2 + q2 ^ 2 + q3 ^ 2) / q0);
        seita = seita * 180 / pi;
        disp(['Before:', num2str(vector_before(4)), '  After:', num2str(vector_after(4))]);
        
        if ((seita <= ROTATION_POS + ROTATION_UP) && (seita >= ROTATION_POS + ROTATION_DOWN)) ||...
                ((seita <= ROTATION_NEG + ROTATION_UP) && (seita >= ROTATION_NEG + ROTATION_DOWN))
            fall_number = fall_number + 1;
            fall_record(fall_number) = count;
            %disp([num2str(count), ' ', num2str(seita)]);
            disp(['Angle:', num2str(seita)]);
        end
        
        flag_quaternion = 0;
        flag_before = 0;
        
    end
    
end % for count

disp(['Fall Number = ', num2str(fall_number)]);




